// Owner-scoped directory UI. Authentication, transport, revisions and drafts are
// owned by the ESTATE controller; this module never accesses Firestore directly.
const PROPERTY_TYPES=[['apartment','아파트'],['officetel','오피스텔'],['house','빌라·주택'],['commercial','상가·사무실'],['land','토지'],['other','기타']];
const DEAL_TYPES=[['sale','매매'],['jeonse','전세'],['rent','월세']];
const PROPERTY_STATUS=[['active','중개 중'],['negotiating','협의 중'],['closed','거래 완료'],['hold','보류'],['ended','중개 종료']];
const COBROKER_SOURCES=[['','미설정'],['own','자체 매물'],['partner','타 중개사 매물']];
const COBROKER_STAGES=[['','미설정'],['available','공동중개 가능'],['active','공동중개 진행'],['finished','공동중개 종료']];
const COBROKER_ROLES=[['','미설정'],['listing','매물 담당'],['customer','고객 담당'],['both','매물·고객 담당']];
const COBROKER_FIELDS=['office','name','phone','role','terms'];
const CUSTOMER_ROLES=[['seller','매도인'],['landlord','임대인'],['buyer','매수인'],['tenant','임차인']];
const YES_NO=[['unknown','확인 필요'],['yes','가능 / 있음'],['no','불가 / 없음']];
const PETS=[...YES_NO,['negotiable','협의 가능']];
const PRIORITY=[['normal','보통'],['high','높음'],['low','낮음']];
const CRITERIA=[['region','희망 지역'],['dealType','거래 유형'],['propertyType','매물 유형'],['price','매매 예산'],['deposit','전세·월세 보증금'],['rent','월세'],['monthlyCost','월 총비용'],['area','면적'],['rooms','방 수'],['moveIn','입주 시기'],['parking','주차'],['elevator','엘리베이터'],['pets','반려동물']];
const PROPERTY_TEXT='title address detailAddress region building buildingUnit unit propertyType dealType direction parking elevator approvalDate managementIncludes availableDate occupancy pets conditions viewingTimes keyMemo ownerCustomerId receivedDate confirmedDate nextCheckDate status coBrokerInfo internalMemo publicDescription advantages disadvantages recommendedBusiness facilities landCategory zoning road'.split(' ');
const PROPERTY_NUMBERS='area supplyArea floor totalFloors rooms bathrooms price deposit rent managementFee premium'.split(' ');
const CUSTOMER_TEXT='name phone email source contactMethod contactTime firstContactDate lastContactDate nextContactDate memo moveInFrom moveInTo parking elevator pets excludedConditions'.split(' ');
const CUSTOMER_NUMBERS='priceMax depositMax rentMax monthlyCostMax areaMin roomsMin'.split(' ');
const text=value=>String(value??'').trim();
const array=value=>Array.isArray(value)?value:[];
const options=rows=>rows.map(([value,label])=>({value,label}));
const label=(rows,value)=>rows.find(row=>row[0]===value)?.[1]||text(value)||'확인 필요';
const numeric=value=>{if(text(value)==='')return null;const result=Number(value);if(!Number.isFinite(result))throw Error('금액과 수량을 숫자로 입력해주세요.');return result;};
const split=value=>[...new Set(text(value).split(/[\n,]+/).map(text).filter(Boolean))];
const plainFields=(data,names)=>Object.fromEntries(names.map(name=>[name,text(data[name])]));
const numberFields=(data,names)=>Object.fromEntries(names.map(name=>[name,numeric(data[name])]));
const localRows=rows=>array(rows).filter(row=>row&&!row.archived&&!row.deletedAt);
const DETAIL_FILTERS={priceMin:'',priceMax:'',rentMax:'',areaMin:'',availableBy:'',availability:'',confirmed:''};
const knownNumber=value=>{if(value==null||typeof value==='boolean'||text(value)==='')return null;const n=Number(value);return Number.isFinite(n)&&n>=0?n:null;};
const dateDay=value=>{const s=text(value);if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return null;const n=Date.parse(s+'T00:00:00Z');return Number.isFinite(n)&&new Date(n).toISOString().slice(0,10)===s?n/86400000:null;};
// A legacy positive flag still means available; reading never rewrites the old row.
const coBrokerStage=row=>text(row.coBrokerStage)||(row.coBroker===true?'available':'');
const hasCoBroker=row=>!!(coBrokerStage(row)||row.coBrokerSource==='partner'||array(row.coBrokers).length||text(row.coBrokerInfo));
const isOwnProperty=row=>row.coBrokerSource==='own'||(!text(row.coBrokerSource)&&!hasCoBroker(row));
const coBrokerSearch=row=>array(row.coBrokers).flatMap(partner=>[partner.office,partner.name,partner.phone]);

function createDownloadShelf(app,host,signal,className){
  const owner=app.uid(),ready=new Map(),pending=new Map(),versions=new Map(),surface=globalThis.window;let disposed=false;
  function remove(id){versions.set(id,(versions.get(id)||0)+1);const item=ready.get(id);if(item){URL.revokeObjectURL(item.url);item.node.remove();ready.delete(id);}}
  function dispose(){if(disposed)return;disposed=true;for(const id of [...ready.keys()])remove(id);surface?.removeEventListener('aiderdear-firebase-state',checkOwner);surface?.removeEventListener('aiderdear-firebase-ready',checkOwner);}
  function checkOwner(){if(app.uid()!==owner)dispose();}
  function assertActive(){if(disposed||signal?.aborted||app.uid()!==owner||!host.isConnected){dispose();throw Error('화면 또는 로그인 계정이 변경되었습니다. 첨부를 다시 준비해주세요.');}}
  function activateLink(item){try{item.link.click();}catch{/* The connected, visible save link remains available for a direct gesture. */}app.notice('파일 준비 완료 · 자동 다운로드가 시작되지 않으면 파일 저장을 눌러주세요.');}
  async function prepare(id){
    assertActive();if(ready.has(id)){activateLink(ready.get(id));return ready.get(id);}if(pending.has(id))return pending.get(id);
    const version=versions.get(id)||0;
    const work=(async()=>{
      try{
        const file=await app.api.download(id);assertActive();if((versions.get(id)||0)!==version)return;
        const url=URL.createObjectURL(file.blob),node=document.createElement('div'),message=document.createElement('span'),link=document.createElement('a');
        node.className=className;node.dataset.estateDownloadReady=id;
        message.textContent='준비 완료 · 자동 다운로드가 시작되지 않으면 아래 파일 저장을 누르세요.';
        link.href=url;link.download=file.name||'첨부 파일';link.rel='noopener';link.textContent='파일 저장 · '+(file.name||'첨부 파일');
        link.addEventListener('click',event=>{try{assertActive();}catch(error){event.preventDefault();app.notice(error.message,true);}});
        node.append(message,link);host.append(node);const item={url,node,link};ready.set(id,item);activateLink(item);return item;
      }finally{pending.delete(id);}
    })();pending.set(id,work);return work;
  }
  signal?.addEventListener('abort',dispose,{once:true});
  surface?.addEventListener('aiderdear-firebase-state',checkOwner);
  surface?.addEventListener('aiderdear-firebase-ready',checkOwner);
  return {prepare,remove,dispose};
}

export function installDirectory(app){
  const esc=value=>app.esc(String(value??''));
  const viewStates=new Map(),mediaNames=new Map();let stateOwner='';
  const alive=(container,signal)=>!signal?.aborted&&container.isConnected;
  const on=(node,event,handler,signal)=>node?.addEventListener(event,handler,signal?{signal}:undefined);
  const money=value=>value==null||value===''?'미확인':app.money(Number(value));
  const field=(name,title,type,value,attrs)=>app.field(name,title,type,value,attrs);
  const select=(name,title,value,rows)=>{
    if(name==='directorySort')rows=rows.map(([key,label])=>[key,label==='매물명'?'매물명 가나다순':label]);
    return field(name,title,'select',value,options(text(value)&&!rows.some(row=>row[0]===value)?[...rows,[value,value]]:rows));
  };
  const note=message=>`<p class="estate-directory-note">${esc(message)}</p>`;
  const section=(title,content,extra='')=>`<details class="estate-directory-section" open ${extra}><summary>${esc(title)}</summary><div class="estate-directory-fields">${content}</div></details>`;
  function checks(name,title,rows,selected=[]){return `<fieldset class="estate-directory-checks"><legend>${esc(title)}</legend>${rows.map(([value,item])=>`<label><input type="checkbox" name="${esc(name)}" value="${esc(value)}" ${selected.includes(value)?'checked':''}><span>${esc(item)}</span></label>`).join('')}</fieldset>`;}
  function bool(name,title,value){return `<label class="estate-directory-boolean"><input type="checkbox" name="${esc(name)}" value="1" ${value?'checked':''}><span>${esc(title)}</span></label>`;}
  function statusBadge(row){return `<span class="estate-directory-badge estate-directory-status-${esc(row.status||'active')}">${esc(label(PROPERTY_STATUS,row.status||'active'))}</span>`;}
  function coBrokerBadge(row){
    if(!hasCoBroker(row))return '';
    const stage=coBrokerStage(row),offices=[...new Set(array(row.coBrokers).map(partner=>text(partner.office)).filter(Boolean))];
    return `<span class="estate-cobroker-summary"><span class="estate-cobroker-badge estate-cobroker-${esc(stage||'unset')}">${esc(stage?label(COBROKER_STAGES,stage):'공동중개 · 상태 미설정')}</span><span class="estate-cobroker-offices">${esc(offices.length?offices.join(' · '):'사무소 미입력')}</span></span>`;
  }
  function propertyPrice(row){if(row.dealType==='rent')return `보증금 ${money(row.deposit)} · 월 ${money(row.rent)}`;if(row.dealType==='jeonse')return `전세 ${money(row.deposit)}`;return `${label(DEAL_TYPES,row.dealType)} ${money(row.price)}`;}
  function propertySubtitle(row){return [row.address,row.detailAddress,[row.building,row.buildingUnit,row.unit].filter(Boolean).join(' ')].filter(Boolean).join(' · ');}
  function customerSubtitle(row){return [row.phone,array(row.roles).map(value=>label(CUSTOMER_ROLES,value)).join('·'),row.source].filter(Boolean).join(' · ');}
  function rowTitle(collection,row){return collection==='customers'?(row.name||'이름 없음'):(row.title||row.number||'제목 없음');}
  function rowSubtitle(collection,row){return collection==='customers'?customerSubtitle(row):collection==='properties'?propertySubtitle(row):[row.stage,row.date].filter(Boolean).join(' · ');}
  function dispatchDraft(input){input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}
  async function hydrateImages(container,signal){
    await Promise.allSettled([...container.querySelectorAll('[data-estate-directory-photo]')].map(async img=>{
      try{const url=await app.api.image(img.dataset.estateDirectoryPhoto);if(alive(img,signal)){img.src=url;img.hidden=false;img.parentElement?.classList.add('estate-directory-photo-ready');}}
      catch{if(alive(img,signal))img.parentElement?.classList.add('estate-directory-photo-unavailable');}
    }));
  }
  function photoMarkup(row){const cover=array(row.photos)[0],id=cover?.thumbId||cover?.mediaId;return `<div class="estate-directory-cover">${id?`<img data-estate-directory-photo="${esc(id)}" alt="${esc(row.title||'매물')} 대표 사진" loading="lazy" hidden>`:''}<span>${id?'사진 불러오는 중':'등록된 사진 없음'}</span></div>`;}
  function stateFor(collection){
    const uid=app.uid();if(uid!==stateOwner){viewStates.clear();mediaNames.clear();stateOwner=uid;}
    if(!viewStates.has(collection))viewStates.set(collection,{rows:[],cursor:null,loaded:false,busy:false,q:'',mode:'list',status:'',type:'',deal:'',role:'',region:'',coBroker:'',sort:'recent',...DETAIL_FILTERS,detailsOpen:false,global:null,sequence:0});
    return viewStates.get(collection);
  }
  function mergedRows(previous,received){const map=new Map(previous.map(row=>[row.id,row]));received.forEach(row=>map.set(row.id,row));return [...map.values()];}
  function detailFilterWarning(state){if(['priceMin','priceMax','rentMax','areaMin'].some(key=>text(state[key])!==''&&knownNumber(state[key])===null))return '가격·면적 조건은 0 이상의 숫자로 입력해주세요.';if(text(state.priceMin)!==''&&text(state.priceMax)!==''&&Number(state.priceMin)>Number(state.priceMax))return '최소 가격은 최대 가격 이하여야 합니다.';if(state.availableBy&&dateDay(state.availableBy)===null)return '입주일 상한을 올바른 날짜로 입력해주세요.';return '';}
  function matchesPropertyDetails(row,state,today){
    if(detailFilterWarning(state))return false;
    const price=row.dealType==='sale'?knownNumber(row.price):['jeonse','rent'].includes(row.dealType)?knownNumber(row.deposit):null;
    const min=knownNumber(state.priceMin),max=knownNumber(state.priceMax),rentMax=knownNumber(state.rentMax),areaMin=knownNumber(state.areaMin);
    if(min!==null&&(price===null||price<min)||max!==null&&(price===null||price>max))return false;
    if(rentMax!==null&&row.dealType==='rent'&&(knownNumber(row.rent)===null||knownNumber(row.rent)>rentMax))return false;
    if(areaMin!==null&&(knownNumber(row.area)===null||knownNumber(row.area)<areaMin))return false;
    const available=dateDay(row.availableDate),by=dateDay(state.availableBy),availability=row.availableNegotiable===true?'negotiable':available===null?'unknown':'confirmed';
    if(state.availability&&availability!==state.availability)return false;
    // Negotiation never implies an earlier date. Unknown dates cannot satisfy a cap.
    if(by!==null&&(available===null||available>by))return false;
    const checked=dateDay(row.confirmedDate),age=checked===null?null:today-checked;
    if(state.confirmed==='week'&&(age===null||age<0||age>7))return false;
    if(state.confirmed==='stale'&&!(age===null||age>30))return false;
    return true;
  }
  function filteredRows(state,collection){
    const q=state.q.toLocaleLowerCase(),region=state.region.toLocaleLowerCase(),today=dateDay(app.today());
    const rows=localRows(state.rows).filter(row=>{
      if(q&&![row.number,row.title,row.address,row.detailAddress,row.building,row.unit,row.name,row.phone,row.email,row.memo,...(collection==='properties'?coBrokerSearch(row):[])].some(value=>text(value).toLocaleLowerCase().includes(q)))return false;
      if(collection==='properties')return (!state.status||row.status===state.status)&&(!state.type||row.propertyType===state.type)&&(!state.deal||row.dealType===state.deal)&&(!state.coBroker||(state.coBroker==='own'?isOwnProperty(row):coBrokerStage(row)===state.coBroker))&&(!region||[row.region,row.address].some(value=>text(value).toLocaleLowerCase().includes(region)))&&matchesPropertyDetails(row,state,today);
      return (!state.role||array(row.roles).includes(state.role))&&(!region||array(row.regions).some(value=>text(value).toLocaleLowerCase().includes(region)));
    });
    // Property name pages already have a global title + ID order. A per-page
    // localeCompare would disagree with Firestore for mixed-script titles.
    if(collection==='properties'&&state.sort==='name')return rows;
    return rows.sort((a,b)=>state.sort==='name'?rowTitle(collection,a).localeCompare(rowTitle(collection,b),'ko'):state.sort==='next'?text(a.nextCheckDate||a.nextContactDate||'9999').localeCompare(text(b.nextCheckDate||b.nextContactDate||'9999')):Number(b.updatedAt||b.createdAt||0)-Number(a.updatedAt||a.createdAt||0));
  }
  async function directoryView(collection,{container,signal}){
    const state=stateFor(collection),property=collection==='properties',title=property?'매물 관리':'고객 관리';let busy=false,loadError=false,requestSequence=0;
    const advancedFilters=property?`<details class="estate-directory-advanced" data-directory-advanced ${state.detailsOpen?'open':''}><summary>상세 조건 <span data-directory-detail-count>가격 · 면적 · 입주 · 확인일</span></summary><div class="estate-directory-filter-grid">${field('directoryPriceMin','최소 가격 · 매매가/보증금 (원)','number',state.priceMin,{min:0,step:1})}${field('directoryPriceMax','최대 가격 · 매매가/보증금 (원)','number',state.priceMax,{min:0,step:1})}${field('directoryRentMax','월세 상한 · 월세 매물만 (원)','number',state.rentMax,{min:0,step:1})}${field('directoryAreaMin','최소 전용/대지 면적 (㎡)','number',state.areaMin,{min:0,step:'any'})}${field('directoryAvailableBy','입주 가능일 상한','date',state.availableBy)}${select('directoryAvailability','입주일 정보',state.availability,[['','전체'],['confirmed','날짜 확인 · 협의 아님'],['negotiable','협의 가능'],['unknown','날짜 미확인']])}${select('directoryConfirmed','최근 확인',state.confirmed,[['','전체'],['week','7일 이내'],['stale','30일 초과 · 미확인']])}</div>${note('금액·면적 미확인 값은 0이 아니며 수치 조건에서 제외됩니다. 입주일 상한은 입력된 날짜만 비교합니다. 협의가 더 이른 입주를 보장하지 않으며, 날짜 없는 매물은 상한 검색에서 제외됩니다.')}</details>`:'';
    container.innerHTML=`<div class="estate-directory"><header class="estate-directory-heading"><div><span class="estate-directory-eyebrow">${property?'PROPERTY DIRECTORY':'CUSTOMER DIRECTORY'}</span><h2>${title}</h2><p>${property?'매물의 조건과 확인 이력을 한곳에서 관리합니다.':'연락처, 희망 조건과 상담 흐름을 이어서 기록합니다.'}</p></div><button type="button" class="estate-directory-primary" data-directory-new>+ ${property?'매물':'고객'} 등록</button></header><div class="estate-directory-toolbar"><label class="estate-directory-search"><span>${property?'번호·주소·제목·공동중개':'이름·연락처'} 검색</span><input type="search" data-directory-query value="${esc(state.q)}" placeholder="불러온 자료에서 검색"><button type="button" data-directory-global>전체 자료 검색</button></label><div class="estate-directory-filter-grid">${property?select('directoryStatus','상태',state.status,[['','모든 상태'],...PROPERTY_STATUS])+select('directoryType','매물 유형',state.type,[['','모든 유형'],...PROPERTY_TYPES])+select('directoryDeal','거래 유형',state.deal,[['','모든 거래'],...DEAL_TYPES])+select('directoryCoBroker','공동중개',state.coBroker,[['','전체'],['own','자체 매물'],...COBROKER_STAGES.filter(([value])=>value)]):select('directoryRole','고객 역할',state.role,[['','모든 역할'],...CUSTOMER_ROLES])}${field('directoryRegion',property?'지역 / 주소':'희망 지역','text',state.region)}${select('directorySort','정렬',state.sort,[['recent','최근 수정'],['name',property?'매물명':'고객명'],['next',property?'다음 확인일':'다음 연락일']])}</div>${advancedFilters}${property?note('공동중개 업체·담당자·연락처 검색과 분류는 불러온 자료 범위에 적용됩니다. 전체 자료 검색은 매물 기본정보를 검색합니다.'):''}<div class="estate-directory-list-meta"><p data-directory-range aria-live="polite"></p><div class="estate-directory-view-buttons" role="group" aria-label="목록 표시 방식"><button type="button" data-directory-mode="cards" aria-pressed="${state.mode==='cards'}">카드</button><button type="button" data-directory-mode="list" aria-pressed="${state.mode==='list'}">목록</button><button type="button" data-directory-reset>필터 초기화</button></div></div></div><div data-directory-results></div><div class="estate-directory-pagination"><button type="button" data-directory-more>50개 더 불러오기</button><span data-directory-load-status role="status"></span></div></div>`;
    const result=container.querySelector('[data-directory-results]'),range=container.querySelector('[data-directory-range]'),more=container.querySelector('[data-directory-more]'),loadStatus=container.querySelector('[data-directory-load-status]');
    function render(){
      if(!alive(container,signal))return;
      const rows=filteredRows(state,collection),global=state.global;
      range.textContent=global?`전체 자료 검색 · 현재까지 ${global.items.length}개 일치${global.cursor?' · 다음 검색 범위가 남아 있습니다.':' · 검색 완료'}`:`불러온 ${localRows(state.rows).length}개 중 ${rows.length}개 표시${state.cursor?' · 아직 불러오지 않은 자료가 있습니다.':state.loaded?' · 전체 페이지를 불러왔습니다.':''}`;
      if(property&&state.sort==='name')range.textContent+=' · 한글 가나다순, 숫자·영문 포함 시 문자순';
      if(property){const count=Object.keys(DETAIL_FILTERS).filter(key=>text(state[key])!=='').length;container.querySelector('[data-directory-detail-count]').textContent=count?`· ${count}개 ${global?'(불러온 목록용)':'적용'}`:'가격 · 면적 · 입주 · 확인일';if(!global&&detailFilterWarning(state))range.textContent+=' · '+detailFilterWarning(state);}
      more.hidden=global?!global.cursor:!state.cursor&&!loadError;more.disabled=busy;more.textContent=global?'다음 검색 범위 불러오기':loadError?'다시 불러오기':'50개 더 불러오기';
      container.querySelectorAll('[data-directory-mode]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.directoryMode===state.mode)));
      if(global){result.innerHTML=`${note('전체 검색은 입력한 검색어로 서버 자료를 찾습니다. 위의 상세·분류 필터는 불러온 목록에만 적용됩니다.')}<div class="estate-directory-global-results">${global.items.length?global.items.map(item=>`<button type="button" class="estate-directory-search-result" data-directory-open="${esc(item.id)}"><b>${esc(item.label)}</b><span>${esc(item.subtitle)}</span></button>`).join(''):`<div class="estate-directory-empty">${global.cursor?'현재 검색 범위에는 일치하는 자료가 없습니다. 다음 범위를 확인할 수 있습니다.':'검색어와 일치하는 자료가 없습니다.'}</div>`}</div>`;}
      else if(!rows.length){result.innerHTML=`<div class="estate-directory-empty">${!state.loaded?'자료를 불러오고 있습니다.':state.rows.length?'현재 불러온 범위에 조건과 일치하는 자료가 없습니다.':`등록된 ${property?'매물':'고객'}이 없습니다. 첫 기록을 등록해주세요.`}</div>`;}
      else if(state.mode==='cards'){
        result.innerHTML=`<div class="estate-directory-cards">${rows.map(row=>property?`<button type="button" class="estate-directory-property-card" data-directory-open="${esc(row.id)}">${photoMarkup(row)}<div class="estate-directory-card-content"><div class="estate-directory-card-top"><small>${esc(row.number||'번호 발급 대기')}</small>${statusBadge(row)}</div><h3>${esc(row.title)}</h3>${coBrokerBadge(row)}<p>${esc(propertySubtitle(row)||'주소 미입력')}</p><strong>${esc(propertyPrice(row))}</strong><div class="estate-directory-card-facts"><span>${esc(label(PROPERTY_TYPES,row.propertyType))}</span><span>${row.area==null?'면적 미확인':esc(row.area)+'㎡'}</span><span>${row.floor==null?'층 미확인':esc(row.floor)+'층'}</span></div><small>최근 확인 ${esc(row.confirmedDate||'미확인')} · ${row.nextCheckDate?'다음 확인 '+esc(row.nextCheckDate):'다음 확인일 미정'}</small></div></button>`:`<button type="button" class="estate-directory-customer-card" data-directory-open="${esc(row.id)}"><div class="estate-directory-card-top"><span class="estate-directory-avatar" aria-hidden="true">${esc((row.name||'고').slice(0,1))}</span><small>${row.nextContactDate?'다음 연락 '+esc(row.nextContactDate):'다음 연락일 미정'}</small></div><h3>${esc(row.name)}</h3><p>${esc(row.phone||'연락처 미입력')}</p><div class="estate-directory-tags">${array(row.roles).map(value=>`<span>${esc(label(CUSTOMER_ROLES,value))}</span>`).join('')}</div><p>${esc(array(row.regions).join(' · ')||'희망 지역 미입력')}</p><small>${row.lastContactDate?'마지막 연락 '+esc(row.lastContactDate):'연락 이력 미입력'}</small></button>`).join('')}</div>`;
      }else{
        result.innerHTML=`<div class="estate-directory-table-wrap"><table class="estate-directory-table"><thead><tr>${(property?['매물 / 대표 사진','거래 / 금액','면적 / 층','상태','최근 확인','다음 확인']:['고객','역할','희망 지역','마지막 연락','다음 연락']).map(value=>`<th scope="col">${value}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>property?`<tr><td><button type="button" class="estate-directory-table-property" data-directory-open="${esc(row.id)}">${photoMarkup(row)}<span><b>${esc(row.title)}</b><small>${esc(row.number)} · ${esc(propertySubtitle(row))}</small>${coBrokerBadge(row)}</span></button></td><td>${esc(propertyPrice(row))}</td><td>${esc(label(PROPERTY_TYPES,row.propertyType))}<small>${row.area==null?'면적 미확인':esc(row.area)+'㎡'} · ${row.floor==null?'층 미확인':esc(row.floor)+'층'}${row.totalFloors==null?'':' / 총 '+esc(row.totalFloors)+'층'}</small></td><td>${statusBadge(row)}</td><td>${esc(row.confirmedDate||'미확인')}</td><td>${esc(row.nextCheckDate||'미정')}</td></tr>`:`<tr><td><button type="button" data-directory-open="${esc(row.id)}"><b>${esc(row.name)}</b><small>${esc(row.phone)}</small></button></td><td>${esc(array(row.roles).map(value=>label(CUSTOMER_ROLES,value)).join(' · '))}</td><td>${esc(array(row.regions).join(' · ')||'미입력')}</td><td>${esc(row.lastContactDate||'미입력')}</td><td>${esc(row.nextContactDate||'미정')}</td></tr>`).join('')}</tbody></table></div>`;
      }
      if(!global)hydrateImages(result,signal);
    }
    async function load(next=false){
      if(busy)return;busy=true;const operation=++requestSequence,byName=property&&state.sort==='name';loadError=false;loadStatus.textContent='자료 불러오는 중…';render();
      try{const page=await app.list(collection,{limit:50,...(byName?{sort:'name'}:{}),...(next&&state.cursor?{cursor:state.cursor}:{})});if(!alive(container,signal)||operation!==requestSequence)return;state.rows=mergedRows(byName&&!next?[]:state.rows,array(page.rows));state.cursor=page.cursor||null;state.loaded=true;loadStatus.textContent='';}
      catch(error){if(alive(container,signal)&&operation===requestSequence){loadError=true;loadStatus.textContent=error.message||'자료를 불러오지 못했습니다.';app.notice(loadStatus.textContent,true);}}
      finally{if(operation===requestSequence){busy=false;render();}}
    }
    function reloadOrder(){
      requestSequence++;state.sequence++;busy=false;loadError=false;
      state.rows=[];state.cursor=null;state.loaded=false;state.global=null;
      return load();
    }
    async function search(next=false){
      const q=text(state.q);if(!q){app.notice('전체 검색어를 입력해주세요.');return}if(busy)return;
      busy=true;const sequence=++state.sequence,operation=++requestSequence;loadStatus.textContent='전체 자료 검색 중…';render();
      try{const page=await app.api.call('search',{q,...(property&&state.sort==='name'?{collection,sort:'name'}:{}),...(next&&state.global?.cursor?{cursor:state.global.cursor}:{})});if(!alive(container,signal)||sequence!==state.sequence||operation!==requestSequence)return;const found=array(page.results).filter(item=>item.collection===collection);state.global={items:mergedRows(next?state.global?.items||[]:[],found),cursor:page.cursor||null};loadStatus.textContent='';}
      catch(error){if(alive(container,signal)&&operation===requestSequence){loadStatus.textContent=error.message||'전체 검색에 실패했습니다.';app.notice(loadStatus.textContent,true);}}
      finally{if(operation===requestSequence){busy=false;if(sequence!==state.sequence)loadStatus.textContent='';render();}}
    }
    on(container.querySelector('[data-directory-new]'),'click',()=>app.open(collection),signal);
    on(container.querySelector('[data-directory-query]'),'input',event=>{state.q=event.target.value;state.global=null;state.sequence++;render();},signal);
    on(container.querySelector('[data-directory-query]'),'keydown',event=>{if(event.key==='Enter'){event.preventDefault();search();}},signal);
    on(container.querySelector('[data-directory-global]'),'click',()=>search(),signal);
    const filterNames={directoryStatus:'status',directoryType:'type',directoryDeal:'deal',directoryCoBroker:'coBroker',directoryRole:'role',directoryRegion:'region',directorySort:'sort',directoryPriceMin:'priceMin',directoryPriceMax:'priceMax',directoryRentMax:'rentMax',directoryAreaMin:'areaMin',directoryAvailableBy:'availableBy',directoryAvailability:'availability',directoryConfirmed:'confirmed'};
    Object.entries(filterNames).forEach(([name,key])=>on(container.querySelector(`[name="${name}"]`),['region','priceMin','priceMax','rentMax','areaMin'].includes(key)?'input':'change',event=>{const previous=state[key];state[key]=event.target.value;state.global=null;state.sequence++;if(property&&key==='sort'&&previous!==state.sort&&(previous==='name'||state.sort==='name'))return reloadOrder();render();},signal));
    on(container.querySelector('[data-directory-advanced]'),'toggle',event=>{state.detailsOpen=event.target.open;},signal);
    on(container.querySelector('[data-directory-reset]'),'click',()=>{const wasName=property&&state.sort==='name';Object.assign(state,{q:'',status:'',type:'',deal:'',role:'',region:'',coBroker:'',sort:'recent',...DETAIL_FILTERS,global:null});state.sequence++;container.querySelector('[data-directory-query]').value='';Object.entries(filterNames).forEach(([name,key])=>{const input=container.querySelector(`[name="${name}"]`);if(input)input.value=state[key];});if(wasName)return reloadOrder();render();},signal);
    container.querySelectorAll('[data-directory-mode]').forEach(button=>on(button,'click',()=>{state.mode=button.dataset.directoryMode;render();},signal));
    on(result,'click',event=>{const button=event.target.closest('[data-directory-open]');if(button)app.open(collection,button.dataset.directoryOpen);},signal);
    on(more,'click',()=>state.global?search(true):load(true),signal);
    if(!(property&&state.sort==='name'))state.rows=mergedRows(state.rows,localRows(app.options(collection)));render();await load();
  }

  function relationField(name,title,collection,id='',required=false){
    return `<div class="estate-directory-relation" data-directory-relation="${esc(name)}" data-relation-collection="${esc(collection)}"><label>${esc(title)}${required?' <span aria-hidden="true">*</span>':''}<input type="hidden" name="${esc(name)}" value="${esc(id)}"></label><div class="estate-directory-relation-current" aria-live="polite">${id?'연결된 기록을 불러오는 중…':'연결된 기록 없음'}</div><div class="estate-directory-relation-actions"><button type="button" data-relation-browse>기존 기록 찾기</button><button type="button" data-relation-clear ${id?'':'hidden'}>연결 해제</button></div><div data-relation-browser hidden><div class="estate-directory-relation-search"><input type="search" aria-label="${esc(title)} 전체 검색" placeholder="이름·번호·주소로 전체 검색"><button type="button" data-relation-search>검색</button></div><p class="estate-directory-note" data-relation-state></p><div class="estate-directory-relation-results"></div><button type="button" data-relation-more hidden>다음 검색 범위</button></div></div>`;
  }
  async function bindRelations(form,signal){
    await Promise.allSettled([...form.querySelectorAll('[data-directory-relation]')].map(async host=>{
      const collection=host.dataset.relationCollection,input=host.querySelector('input[type="hidden"]'),current=host.querySelector('.estate-directory-relation-current'),browser=host.querySelector('[data-relation-browser]'),result=host.querySelector('.estate-directory-relation-results'),status=host.querySelector('[data-relation-state]'),query=host.querySelector('input[type="search"]'),more=host.querySelector('[data-relation-more]'),clear=host.querySelector('[data-relation-clear]');
      let results=[],cursor=null,busy=false,sequence=0;
      async function currentLabel(){const id=input.value;if(!id){current.textContent='연결된 기록 없음';clear.hidden=true;return}clear.hidden=false;try{const row=await app.lookup(collection,id);if(alive(host,signal)&&input.value===id)current.textContent=row?`${rowTitle(collection,row)} · ${rowSubtitle(collection,row)}`:'연결 기록을 찾을 수 없습니다. 다시 선택해주세요.';}catch(error){if(alive(host,signal))current.textContent=error.message||'연결 정보를 불러오지 못했습니다.';}}
      function renderResults(){if(!alive(host,signal))return;result.innerHTML=results.length?results.map(item=>`<button type="button" data-relation-id="${esc(item.id)}"><b>${esc(item.label)}</b><span>${esc(item.subtitle)}</span></button>`).join(''):'<p class="estate-directory-note">현재 범위에 선택할 기록이 없습니다.</p>';more.hidden=!cursor;more.disabled=busy;}
      async function browse(){if(busy)return;browser.hidden=!browser.hidden;if(browser.hidden)return;busy=true;status.textContent='기존 기록을 불러오는 중…';try{const received=await app.pickOptions(collection);if(!alive(host,signal))return;results=localRows(Array.isArray(received)?received:received?.rows).slice(0,50).map(row=>({id:row.id,label:rowTitle(collection,row),subtitle:rowSubtitle(collection,row)}));cursor=null;status.textContent='먼저 불러온 최대 50개입니다. 다른 기록은 전체 검색으로 찾으세요.';renderResults();}catch(error){status.textContent=error.message||'기록을 불러오지 못했습니다.';}finally{busy=false;}}
      async function search(next=false){const q=text(query.value);if(!q){status.textContent='검색어를 입력해주세요.';return}if(busy)return;busy=true;const token=++sequence;status.textContent='전체 자료를 검색하는 중…';try{const page=await app.api.call('search',{q,...(next&&cursor?{cursor}:{})});if(!alive(host,signal)||token!==sequence)return;const found=array(page.results).filter(item=>item.collection===collection);results=mergedRows(next?results:[],found);cursor=page.cursor||null;status.textContent=`현재까지 ${results.length}개 일치${cursor?' · 아직 검색할 범위가 있습니다.':' · 검색 완료'}`;renderResults();}catch(error){status.textContent=error.message||'검색에 실패했습니다.';}finally{busy=false;more.disabled=false;}}
      on(host.querySelector('[data-relation-browse]'),'click',browse,signal);on(host.querySelector('[data-relation-search]'),'click',()=>search(),signal);on(more,'click',()=>search(true),signal);
      on(query,'keydown',event=>{if(event.key==='Enter'){event.preventDefault();search();}},signal);
      on(query,'input',()=>{sequence++;cursor=null;more.hidden=true;},signal);
      on(result,'click',event=>{const button=event.target.closest('[data-relation-id]');if(!button)return;input.value=button.dataset.relationId;const selected=results.find(row=>row.id===input.value);current.textContent=[selected?.label,selected?.subtitle].filter(Boolean).join(' · ');clear.hidden=false;browser.hidden=true;dispatchDraft(input);},signal);
      on(clear,'click',()=>{input.value='';dispatchDraft(input);currentLabel();},signal);await currentLabel();
    }));
  }

  async function relatedRows(host,collection,predicate,renderRow,signal){
    let rows=[],cursor=null,busy=false,scanned=0;host.innerHTML='<div class="estate-directory-related-items"></div><p class="estate-directory-note" data-related-state></p><button type="button" data-related-more>50개 범위 더 확인</button>';
    const body=host.querySelector('.estate-directory-related-items'),status=host.querySelector('[data-related-state]'),more=host.querySelector('[data-related-more]');
    async function load(){if(busy)return;busy=true;more.disabled=true;status.textContent='연결 기록을 불러오는 중…';try{const page=await app.list(collection,{limit:50,...(cursor?{cursor}:{})});if(!alive(host,signal))return;scanned+=array(page.rows).length;rows=mergedRows(rows,localRows(page.rows).filter(predicate)).sort((a,b)=>text(b.date||b.updatedAt).localeCompare(text(a.date||a.updatedAt)));cursor=page.cursor||null;body.innerHTML=rows.length?rows.map(renderRow).join(''):'<div class="estate-directory-empty estate-directory-empty-small">현재 불러온 범위에 연결된 기록이 없습니다.</div>';status.textContent=`확인한 ${scanned}개 중 연결된 기록 ${rows.length}개${cursor?' · 더 확인할 자료가 있습니다.':' · 전체 범위 확인 완료'}`;more.hidden=!cursor;}catch(error){status.textContent=error.message||'연결 기록을 불러오지 못했습니다.';}finally{busy=false;more.disabled=false;}}
    on(more,'click',load,signal);on(body,'click',event=>{const button=event.target.closest('[data-related-open]');if(button)app.open(collection,button.dataset.relatedOpen);},signal);await load();
  }
  function timelineRow(row){return `<button type="button" class="estate-directory-timeline-item" data-related-open="${esc(row.id)}"><time>${esc(row.date)} ${esc(row.time)}</time><b>${esc(row.method||'상담')}</b><p>${esc(row.content)}</p>${row.nextAction?`<span class="estate-directory-followup">다음 행동 · ${esc(row.nextAction)}${row.dueDate?' / '+esc(row.dueDate):''}</span>`:''}</button>`;}
  function proposalRow(row){return `<button type="button" class="estate-directory-timeline-item" data-related-open="${esc(row.id)}"><time>${esc(row.date)}</time><b>${esc(label([['suggested','제안함'],['interested','관심 있음'],['declined','거절']],row.status))}</b><p>${esc(row.notes||'추가 메모 없음')}</p><small>매물 ${esc(app.options('properties').find(item=>item.id===row.propertyId)?.title||'상세에서 확인')}</small></button>`;}
  function visitRow(row){return `<button type="button" class="estate-directory-timeline-item" data-related-open="${esc(row.id)}"><time>${esc(row.date)} ${esc(row.time)}</time><b>${esc(label([['scheduled','방문 예정'],['done','방문 완료'],['cancelled','방문 취소']],row.status))}</b><p>${esc(row.reaction||'방문 반응 미입력')}</p>${row.followUpAction?`<small>후속 행동 · ${esc(row.followUpAction)} ${esc(row.followUpDate)}</small>`:''}</button>`;}
  function dealRow(row){return `<button type="button" class="estate-directory-timeline-item" data-related-open="${esc(row.id)}"><time>${esc(row.dueDate||row.contractDate||'일정 미정')}</time><b>${esc(row.title||'연결 거래')}</b><p>${esc(label([['inquiry','문의'],['consultation','상담'],['proposal','제안'],['visit','방문'],['negotiation','조건 협의'],['preparation','계약 준비'],['contract','계약 완료'],['settled','잔금·인도 완료'],['hold','보류'],['stopped','중단']],row.stage))}${row.nextAction?' · '+esc(row.nextAction):''}</p></button>`;}
  function offerSavedDetails(form,collection,id){if(!form.isConnected||form.querySelector('[data-saved-directory-open]'))return;const box=document.createElement('div');box.className='estate-directory-saved';box.innerHTML='<p>저장했습니다. 상세 화면에서 상담·방문·거래를 이어서 연결할 수 있습니다.</p><button type="button" data-saved-directory-open>저장한 상세 열기</button>';box.querySelector('button').onclick=()=>app.open(collection,id);form.append(box);}
  function relationSection(title,action,collection,preset){return `<section class="estate-directory-related"><header><h3>${esc(title)}</h3><button type="button" data-directory-related-new="${esc(collection)}" data-related-preset="${esc(JSON.stringify(preset))}">${esc(action)}</button></header><div data-related-collection="${esc(collection)}"></div></section>`;}
  function bindRelatedNew(container,signal){container.querySelectorAll('[data-directory-related-new]').forEach(button=>on(button,'click',()=>app.open(button.dataset.directoryRelatedNew,undefined,JSON.parse(button.dataset.relatedPreset)),signal));}

  function historyMarkup(items){return items.length?`<ol>${items.slice().sort((a,b)=>Number(b.at)-Number(a.at)).map(item=>`<li><time>${esc(item.at?new Date(Number(item.at)).toLocaleString('ko-KR'):'날짜 미확인')}</time><span>${array(item.changes).map(change=>`${esc(({price:'매매가',deposit:'보증금',rent:'월세',status:'상태'})[change.field]||change.field)}: ${esc(change.field==='status'?label(PROPERTY_STATUS,change.before):money(change.before))} → ${esc(change.field==='status'?label(PROPERTY_STATUS,change.after):money(change.after))}`).join(' · ')||esc(item.summary||item.action||'가격·상태 수정')}</span></li>`).join('')}</ol>`:note('가격·상태 변경 이력이 없습니다.');}
  function bindHistory(host,id,signal){if(!host)return ()=>{};let cursor=null,rows=[],busy=false;const more=host.querySelector('[data-history-more]'),body=host.querySelector('[data-history-rows]'),status=host.querySelector('[data-history-status]');on(more,'click',async()=>{if(busy)return;busy=true;more.disabled=true;status.textContent='전체 이력 범위를 확인하는 중…';try{const page=await app.api.call('history',{collection:'properties',id,...(cursor?{cursor}:{})});if(!alive(host,signal))return;rows=mergedRows(rows,array(page.rows));cursor=page.cursor||null;body.innerHTML=historyMarkup(rows);status.textContent=`전체 이력 중 ${rows.length}개를 불러왔습니다.${cursor?' 이전·다음 범위도 계속 확인할 수 있습니다.':' 전체 범위 확인 완료.'}`;more.hidden=!cursor;more.textContent='이력 50개 범위 더 확인';}catch(error){if(alive(host,signal))status.textContent=error.message||'이력을 불러오지 못했습니다.';}finally{busy=false;more.disabled=false;}},signal);return recent=>{cursor=null;rows=[];body.innerHTML=historyMarkup(recent);status.textContent='저장 시점의 최근 최대 100개 이력입니다.';more.hidden=false;more.textContent='전체 이력 범위 조회';};}
  async function propertyPanel({container,row,isNew,signal}){
    stateFor('properties'); // Clear owner-specific display caches even when opened from Today.
    let current={status:'active',propertyType:'apartment',dealType:'sale',parking:'unknown',elevator:'unknown',pets:'unknown',receivedDate:app.today(),...row};
    let refreshHistory=()=>{};let photos=array(current.photos).map(photo=>({...photo})),documents=[...array(current.mediaIds)],removed=new Set(),pendingUploads=0;
    let coBrokers=array(current.coBrokers).map(partner=>({...partner}));
    const title=`<div class="estate-directory-panel-intro"><span class="estate-directory-eyebrow">PROPERTY</span><h2>${isNew?'매물 등록':'매물 상세'}</h2><p>${current.number?'매물번호 '+esc(current.number):'저장하면 매물번호가 자동으로 발급됩니다.'}</p>${note('금액 단위는 원(KRW), 면적은 ㎡입니다. 모르는 수치는 비워 두세요. 주소가 겹치면 서버 확인 안내가 표시됩니다.')}</div>`;
    const referenceLinks=`<details class="estate-directory-references"><summary>공식 가격 · 지도 확인</summary>${note('입력 가격은 의뢰 호가이며 외부 가격과 자동 연동되지 않습니다. 출처와 기준일은 각 서비스에서 확인하세요. 주소나 고객 정보는 자동 전송하지 않습니다.')}<nav aria-label="공식 부동산 정보"><a href="https://rt.molit.go.kr/" target="_blank" rel="noopener noreferrer">국토교통부 실거래가</a><a href="https://rtech.or.kr/" target="_blank" rel="noopener noreferrer">한국부동산원 부동산테크 시세</a><a href="https://www.realtyprice.kr/notice/main/main.do" target="_blank" rel="noopener noreferrer">한국부동산원 공시가격 (시세와 다름)</a><a href="https://www.vworld.kr/" target="_blank" rel="noopener noreferrer">브이월드 공식 지도</a></nav></details>`;
    const basic=section('기본 정보',field('title','매물 제목','text',current.title,{required:true})+select('propertyType','매물 유형',current.propertyType,PROPERTY_TYPES)+select('dealType','거래 유형',current.dealType,DEAL_TYPES)+select('status','매물 상태',current.status,PROPERTY_STATUS)+field('address','주소','text',current.address)+field('detailAddress','상세 주소','text',current.detailAddress)+field('region','지역','text',current.region)+field('building','건물명','text',current.building)+field('buildingUnit','동','text',current.buildingUnit)+field('unit','호','text',current.unit));
    const physical=section('면적과 건물 조건',field('area','전용 / 대지 면적 (㎡)','number',current.area,{min:0,step:'any'})+field('supplyArea','공급 면적 (㎡)','number',current.supplyArea,{min:0,step:'any'})+field('floor','해당 층 (지하는 음수)','number',current.floor,{min:-30,max:300,step:1})+field('totalFloors','총 층수','number',current.totalFloors,{min:0,step:1})+field('rooms','방 수','number',current.rooms,{min:0,step:1})+field('bathrooms','욕실 수','number',current.bathrooms,{min:0,step:1})+field('direction','방향','text',current.direction)+select('parking','주차',current.parking,YES_NO)+select('elevator','엘리베이터',current.elevator,YES_NO)+field('approvalDate','사용 승인일','date',current.approvalDate));
    const terms=section('금액과 입주',field('price','매매 금액 (원)','number',current.price,{min:0,step:1})+field('deposit','전세 / 월세 보증금 (원)','number',current.deposit,{min:0,step:1})+field('rent','월세 (원)','number',current.rent,{min:0,step:1})+field('managementFee','관리비 (원)','number',current.managementFee,{min:0,step:1})+field('managementIncludes','관리비 포함 항목','text',current.managementIncludes)+bool('negotiable','금액 협의 가능',current.negotiable)+field('availableDate','입주 가능일','date',current.availableDate)+bool('availableNegotiable','입주일 협의 가능',current.availableNegotiable)+field('occupancy','현재 점유 상태','text',current.occupancy)+select('pets','반려동물',current.pets,PETS)+field('conditions','거래 / 입주 조건','textarea',current.conditions));
    const special=section('상가 추가 조건',field('premium','권리금 (원)','number',current.premium,{min:0,step:1})+field('recommendedBusiness','추천 업종','text',current.recommendedBusiness)+field('facilities','시설 내역','textarea',current.facilities),'data-property-section="commercial"')+section('토지 추가 조건',field('landCategory','지목','text',current.landCategory)+field('zoning','용도 지역','text',current.zoning)+field('road','도로 / 진입 조건','textarea',current.road),'data-property-section="land"');
    const management=section('연락과 확인',relationField('ownerCustomerId','소유주 / 임대인 고객','customers',current.ownerCustomerId)+field('viewingTimes','방문 가능 시간','text',current.viewingTimes)+field('keyMemo','열쇠 / 출입 메모 (내부)','textarea',current.keyMemo)+field('receivedDate','접수일','date',current.receivedDate)+field('confirmedDate','최근 확인일','date',current.confirmedDate)+field('nextCheckDate','다음 확인일','date',current.nextCheckDate));
    const brokerage=section('공동중개',select('coBrokerSource','매물 출처',current.coBrokerSource,COBROKER_SOURCES)+select('coBrokerStage','공동중개 단계',current.coBrokerStage,COBROKER_STAGES)+bool('coBroker','공동중개 가능 표시',current.coBroker)+note('기존 가능 표시와 메모는 유지됩니다. 단계를 지정하면 그 단계로 표시합니다. 협력 정보는 내부 기록이며 자동 공유되거나 계정이 생성되지 않습니다.')+`<div class="estate-cobroker-editor"><input type="hidden" name="coBrokersJson" value="${esc(JSON.stringify(coBrokers))}"><div class="estate-cobroker-editor-head"><h4>협력 중개사 <span data-cobroker-count></span></h4><button type="button" data-cobroker-add>+ 중개사 추가</button></div><div class="estate-cobroker-partners" data-cobroker-partners></div></div>`+field('coBrokerInfo','공동중개 메모 (기존 기록 포함)','textarea',current.coBrokerInfo)+note('보수 배분액은 아래 연결 거래의 공동중개 배분액에 직접 기록합니다. 파트너별 정산이나 외부 지급은 자동으로 처리하지 않습니다.'),'data-cobroker-section');
    const description=section('소개와 내부 메모',field('publicDescription','외부 소개 문구','textarea',current.publicDescription)+field('advantages','장점','textarea',current.advantages)+field('disadvantages','단점 / 확인 사항','textarea',current.disadvantages)+field('internalMemo','내부 메모','textarea',current.internalMemo));
    const attachments=section('사진과 서류',`<div class="estate-directory-attachment-block"><h4>매물 사진 <small>최대 20장</small></h4>${note('첫 번째 사진이 대표 사진입니다. 순서 변경과 제거는 매물 저장 시 반영됩니다.')}<input type="hidden" name="photosJson" value="${esc(JSON.stringify(photos))}"><label class="estate-directory-upload">사진 여러 장 추가<input type="file" data-photo-upload accept="image/jpeg,image/png,image/webp" multiple></label><div class="estate-directory-photo-grid" data-photo-grid></div></div><div class="estate-directory-attachment-block"><h4>첨부 서류 <small>최대 30개</small></h4><input type="hidden" name="documentsJson" value="${esc(JSON.stringify(documents))}"><label class="estate-directory-upload">서류 추가<input type="file" data-document-upload multiple></label><div data-document-list></div><div class="estate-directory-downloads" data-document-ready aria-live="polite"></div></div><p class="estate-directory-upload-status" data-upload-status role="status" aria-live="polite"></p>`);
    container.innerHTML=`<div class="estate-directory-panel">${title}${referenceLinks}<div data-directory-form></div>${isNew?'':relationSection('매물 상담 기록','상담 추가','consultations',{propertyId:current.id})+relationSection('이 매물의 제안 기록','고객에게 제안','proposals',{propertyId:current.id})+relationSection('방문 기록','방문 추가','visits',{propertyId:current.id})+relationSection('연결 거래','거래 추가','deals',{propertyId:current.id})+`<section class="estate-directory-history" data-property-history><h3>가격 · 상태 변경 이력</h3>${note('최근 최대 100개 이력입니다. 그 이전 이력도 서버에 보존되며 전체 이력 조회로 확인할 수 있습니다.')}<div data-history-rows>${historyMarkup(array(current.history))}</div><p class="estate-directory-note" data-history-status></p><button type="button" data-history-more>전체 이력 범위 조회</button></section>`}</div>`;
    const form=app.form(container.querySelector('[data-directory-form]'),basic+physical+terms+special+management+brokerage+description+attachments,async(data,formElement)=>{
      if(pendingUploads)throw Error('첨부 업로드가 끝난 뒤 저장해주세요.');
      readCoBrokers();
      const stage=text(data.coBrokerStage??current.coBrokerStage),source=text(data.coBrokerSource??current.coBrokerSource);
      const saved=await app.save('properties',{...current,...plainFields(data,PROPERTY_TEXT),...numberFields(data,PROPERTY_NUMBERS),negotiable:!!formElement.elements.negotiable.checked,availableNegotiable:!!formElement.elements.availableNegotiable.checked,coBroker:!!formElement.elements.coBroker.checked||!!stage,coBrokerInfo:text(data.coBrokerInfo??current.coBrokerInfo),coBrokerSource:source,coBrokerStage:stage,coBrokers:coBrokers.map(partner=>({...partner})),photos:photos.map(photo=>({...photo})),mediaIds:[...documents]},formElement);
      current=saved;refreshHistory(array(saved.history));const retained=new Set([...documents,...photos.flatMap(photo=>[photo.mediaId,photo.thumbId].filter(Boolean))]);
      for(const id of removed){if(retained.has(id))continue;try{await app.api.call('mediaDelete',{id});}catch{app.notice('첨부 연결은 제거했습니다. 다른 기록에서 사용 중인 원본 파일은 보존됩니다.');}}removed.clear();if(isNew)offerSavedDetails(form,'properties',saved.id);return saved;
    });
    form.classList.add('estate-directory-form');
    const partnerList=form.querySelector('[data-cobroker-partners]'),partnerAdd=form.querySelector('[data-cobroker-add]');
    const partnerName=(partner,key)=>`coBroker_${partner.id}_${key}`;
    function readCoBrokers(){
      // Snapshot before adding/removing and before a save attempt; no form rebuild on failure.
      coBrokers=coBrokers.map(partner=>({...partner,...Object.fromEntries(COBROKER_FIELDS.map(key=>[key,text(form.elements[partnerName(partner,key)]?.value??partner[key])]))}));
      form.elements.coBrokersJson.value=JSON.stringify(coBrokers);
    }
    function dirtyCoBrokers(){readCoBrokers();dispatchDraft(form.elements.coBrokersJson);}
    function renderCoBrokers(){
      form.querySelector('[data-cobroker-count]').textContent=`${coBrokers.length} / 5`;
      partnerAdd.disabled=coBrokers.length>=5;
      partnerList.innerHTML=coBrokers.length?coBrokers.map((partner,index)=>`<article class="estate-cobroker-partner" data-cobroker-id="${esc(partner.id)}"><header><h4>중개사 ${index+1}</h4><button type="button" data-cobroker-remove="${esc(partner.id)}" aria-label="중개사 ${index+1} 제거">제거</button></header><div class="estate-cobroker-fields">${field(partnerName(partner,'office'),'사무소명','text',partner.office,{maxlength:120})}${field(partnerName(partner,'name'),'담당자','text',partner.name,{maxlength:80})}${field(partnerName(partner,'phone'),'연락처','tel',partner.phone,{maxlength:80})}${select(partnerName(partner,'role'),'담당 역할',partner.role,COBROKER_ROLES)}${field(partnerName(partner,'terms'),'협의 조건 / 보수 약정','textarea',partner.terms,{maxlength:2000})}</div></article>`).join(''):note('등록된 협력 중개사가 없습니다. 필요한 경우 직접 추가해주세요.');
    }
    on(partnerList,'input',dirtyCoBrokers,signal);on(partnerList,'change',dirtyCoBrokers,signal);
    on(partnerAdd,'click',()=>{
      if(coBrokers.length>=5){app.notice('협력 중개사는 최대 5명까지 등록할 수 있습니다.',true);return;}
      readCoBrokers();
      const id=globalThis.crypto.randomUUID();
      coBrokers.push({id,office:'',name:'',phone:'',role:'',terms:''});
      renderCoBrokers();form.elements.coBrokersJson.value=JSON.stringify(coBrokers);dispatchDraft(form.elements.coBrokersJson);
    },signal);
    on(partnerList,'click',event=>{
      const button=event.target.closest('[data-cobroker-remove]');if(!button)return;
      readCoBrokers();coBrokers=coBrokers.filter(partner=>partner.id!==button.dataset.cobrokerRemove);
      renderCoBrokers();form.elements.coBrokersJson.value=JSON.stringify(coBrokers);dispatchDraft(form.elements.coBrokersJson);
    },signal);
    on(form.elements.coBrokerStage,'change',()=>{if(form.elements.coBrokerStage.value&&!form.elements.coBroker.checked){form.elements.coBroker.checked=true;dispatchDraft(form.elements.coBroker);}},signal);
    renderCoBrokers();
    const photoGrid=form.querySelector('[data-photo-grid]'),documentList=form.querySelector('[data-document-list]'),uploadStatus=form.querySelector('[data-upload-status]');
    const downloads=createDownloadShelf(app,form.querySelector('[data-document-ready]'),signal,'estate-directory-download-ready');
    function dirtyMedia(){form.elements.photosJson.value=JSON.stringify(photos);form.elements.documentsJson.value=JSON.stringify(documents);dispatchDraft(form.elements.photosJson);dispatchDraft(form.elements.documentsJson);}
    function renderPhotos(){photoGrid.innerHTML=photos.length?photos.map((photo,index)=>`<article class="estate-directory-photo"><div class="estate-directory-photo-preview"><img data-estate-directory-photo="${esc(photo.thumbId||photo.mediaId)}" alt="${esc(photo.name||'매물 사진')}" hidden><span>${index===0?'대표 사진':index+1}</span></div><p title="${esc(photo.name)}">${esc(photo.name||'사진')}</p><div><button type="button" data-photo-action="cover" data-photo-index="${index}" ${index===0?'disabled':''}>대표</button><button type="button" data-photo-action="up" data-photo-index="${index}" aria-label="${index+1}번 사진 앞으로" ${index===0?'disabled':''}>↑</button><button type="button" data-photo-action="down" data-photo-index="${index}" aria-label="${index+1}번 사진 뒤로" ${index===photos.length-1?'disabled':''}>↓</button><button type="button" data-photo-action="remove" data-photo-index="${index}">제거</button></div></article>`).join(''):note('등록된 사진이 없습니다.');hydrateImages(photoGrid,signal);}
    function renderDocuments(){documentList.innerHTML=documents.length?documents.map((id,index)=>`<div class="estate-directory-document"><span data-document-name="${esc(id)}">${esc(mediaNames.get(id)||'첨부 서류 '+(index+1))}</span><button type="button" data-document-download="${esc(id)}">다운로드</button><button type="button" data-document-remove="${esc(id)}">제거</button></div>`).join(''):note('첨부된 서류가 없습니다.');documents.filter(id=>!mediaNames.has(id)).forEach(async id=>{try{const info=await app.api.call('mediaInfo',{id});mediaNames.set(id,info.name||'첨부 서류');if(alive(documentList,signal)){const name=documentList.querySelector(`[data-document-name="${CSS.escape(id)}"]`);if(name)name.textContent=mediaNames.get(id);}}catch{/* Keep an honest unnamed attachment row with retryable download. */}});}
    async function upload(files,photo){if(!files.length)return;const max=photo?20:30;if((photo?photos.length:documents.length)+files.length>max){app.notice(`${photo?'사진은':'서류는'} 최대 ${max}개까지 등록할 수 있습니다.`,true);return}pendingUploads++;form.querySelectorAll('button[type="submit"]').forEach(button=>button.disabled=true);form.querySelectorAll('input[type="file"]').forEach(input=>input.disabled=true);
      try{for(let i=0;i<files.length;i++){if(signal?.aborted)break;const file=files[i];if(photo&&!/^image\/(jpeg|png|webp)$/.test(file.type))throw Error('사진은 JPG, PNG, WebP 이미지 파일을 선택해주세요.');uploadStatus.textContent=`${i+1}/${files.length} 업로드 · ${file.name}`;const item=await app.api.upload(file,{entityCollection:'properties',entityId:current.id,thumbnail:photo});if(signal?.aborted){await Promise.allSettled([item.id,item.thumbId].filter(Boolean).map(id=>app.api.call('mediaDelete',{id})));break;}if(photo)photos.push({mediaId:item.id,thumbId:item.thumbId||'',name:item.name||file.name});else{documents.push(item.id);mediaNames.set(item.id,item.name||file.name);}if(alive(form,signal)){dirtyMedia();renderPhotos();renderDocuments();}}if(alive(form,signal))uploadStatus.textContent='업로드 완료 · 저장하면 첨부가 연결됩니다.';}
      catch(error){if(alive(form,signal)){uploadStatus.textContent=error.message||'업로드하지 못했습니다.';app.notice(uploadStatus.textContent,true);}}
      finally{pendingUploads--;if(alive(form,signal)){form.querySelectorAll('button[type="submit"]').forEach(button=>button.disabled=false);form.querySelectorAll('input[type="file"]').forEach(input=>{input.disabled=false;input.value='';});}}
    }
    on(form.querySelector('[data-photo-upload]'),'change',event=>upload([...event.target.files],true),signal);on(form.querySelector('[data-document-upload]'),'change',event=>upload([...event.target.files],false),signal);
    on(photoGrid,'click',event=>{const button=event.target.closest('[data-photo-action]');if(!button)return;const index=Number(button.dataset.photoIndex),action=button.dataset.photoAction;if(!photos[index])return;if(action==='remove'){const [item]=photos.splice(index,1);[item.mediaId,item.thumbId].filter(Boolean).forEach(id=>removed.add(id));}else if(action==='cover')photos.unshift(...photos.splice(index,1));else{const target=index+(action==='up'?-1:1);if(target>=0&&target<photos.length)[photos[index],photos[target]]=[photos[target],photos[index]];}dirtyMedia();renderPhotos();},signal);
    on(documentList,'click',async event=>{const remove=event.target.closest('[data-document-remove]');if(remove){const id=remove.dataset.documentRemove;documents=documents.filter(value=>value!==id);removed.add(id);downloads.remove(id);dirtyMedia();renderDocuments();return}const button=event.target.closest('[data-document-download]');if(!button)return;button.disabled=true;try{await downloads.prepare(button.dataset.documentDownload);}catch(error){if(alive(documentList,signal))app.notice(error.message||'첨부를 내려받지 못했습니다.',true);}finally{if(button.isConnected)button.disabled=false;}},signal);
    function conditional(){form.querySelectorAll('[data-property-section]').forEach(section=>section.hidden=section.dataset.propertySection!==form.elements.propertyType.value);}
    on(form.elements.propertyType,'change',conditional,signal);conditional();renderPhotos();renderDocuments();bindRelations(form,signal);bindRelatedNew(container,signal);refreshHistory=bindHistory(container.querySelector('[data-property-history]'),current.id,signal);
    if(!isNew){relatedRows(container.querySelector('[data-related-collection="consultations"]'),'consultations',item=>item.propertyId===current.id,timelineRow,signal);relatedRows(container.querySelector('[data-related-collection="proposals"]'),'proposals',item=>item.propertyId===current.id,proposalRow,signal);relatedRows(container.querySelector('[data-related-collection="visits"]'),'visits',item=>item.propertyId===current.id,visitRow,signal);relatedRows(container.querySelector('[data-related-collection="deals"]'),'deals',item=>item.propertyId===current.id,dealRow,signal);}
  }

  async function customerPanel({container,row,isNew,signal}){
    let current={roles:[],parking:'unknown',elevator:'unknown',pets:'unknown',firstContactDate:app.today(),...row};
    const identity=section('연락처와 고객 역할',field('name','고객 이름','text',current.name,{required:true})+field('phone','연락처','text',current.phone,{required:true})+field('email','이메일','text',current.email)+checks('roles','고객 역할 (복수 선택)',CUSTOMER_ROLES,array(current.roles))+field('source','유입 경로','text',current.source)+field('contactMethod','선호 연락 방법','text',current.contactMethod)+field('contactTime','연락 가능 시간','text',current.contactTime)+field('firstContactDate','최초 문의일','date',current.firstContactDate)+field('lastContactDate','최근 연락일','date',current.lastContactDate)+field('nextContactDate','다음 연락일','date',current.nextContactDate)+field('memo','고객 메모','textarea',current.memo));
    const preferences=section('희망 매물 조건',field('regions','희망 지역 (쉼표 또는 줄바꿈)','textarea',array(current.regions).join('\n'))+field('excludedRegions','제외 지역 (쉼표 또는 줄바꿈)','textarea',array(current.excludedRegions).join('\n'))+checks('dealTypes','희망 거래 유형',DEAL_TYPES,array(current.dealTypes))+checks('propertyTypes','희망 매물 유형',PROPERTY_TYPES,array(current.propertyTypes))+field('priceMax','매매 예산 상한 (원)','number',current.priceMax,{min:0,step:1})+field('depositMax','전세 / 월세 보증금 상한 (원)','number',current.depositMax,{min:0,step:1})+field('rentMax','월세 상한 (원)','number',current.rentMax,{min:0,step:1})+field('monthlyCostMax','월세 + 관리비 상한 (원)','number',current.monthlyCostMax,{min:0,step:1})+field('areaMin','최소 면적 (㎡)','number',current.areaMin,{min:0,step:'any'})+field('roomsMin','최소 방 수','number',current.roomsMin,{min:0,step:1})+field('moveInFrom','입주 희망 시작일','date',current.moveInFrom)+field('moveInTo','입주 희망 종료일','date',current.moveInTo)+select('parking','주차 희망',current.parking,YES_NO)+select('elevator','엘리베이터 희망',current.elevator,YES_NO)+select('pets','반려동물',current.pets,PETS)+field('excludedConditions','피해야 할 조건','textarea',current.excludedConditions));
    const criteria=section('조건의 중요도',`<div class="estate-directory-criteria">${note('필수 조건과 조정 가능한 조건을 구분합니다. 같은 조건을 두 곳에 동시에 선택할 수 없습니다. 금액·지역 등 실제 희망값도 위에서 함께 입력해주세요.')}<div class="estate-directory-criteria-head"><span>조건</span><span>필수</span><span>조정 가능</span></div>${CRITERIA.map(([key,title])=>`<div class="estate-directory-criterion"><span>${esc(title)}</span><label><input type="checkbox" name="required" value="${key}" ${array(current.required).includes(key)?'checked':''}><span class="estate-directory-sr-only">${esc(title)} 필수</span></label><label><input type="checkbox" name="flexible" value="${key}" ${array(current.flexible).includes(key)?'checked':''}><span class="estate-directory-sr-only">${esc(title)} 조정 가능</span></label></div>`).join('')}</div>`);
    container.innerHTML=`<div class="estate-directory-panel"><div class="estate-directory-panel-intro"><span class="estate-directory-eyebrow">CUSTOMER</span><h2>${isNew?'고객 등록':'고객 상세'}</h2>${note('한 고객에게 여러 역할을 연결할 수 있습니다. 상담과 매물 제안은 저장된 고객 기록에 이어집니다.')}</div><div data-directory-form></div>${isNew?'':relationSection('상담 타임라인','상담 추가','consultations',{customerId:current.id})+relationSection('제안한 매물','매물 제안','proposals',{customerId:current.id})+relationSection('방문 기록','방문 추가','visits',{customerIds:[current.id]})+relationSection('진행 거래','거래 추가','deals',{sellerIds:array(current.roles).some(role=>['seller','landlord'].includes(role))?[current.id]:[],buyerIds:array(current.roles).some(role=>['buyer','tenant'].includes(role))?[current.id]:[]})}</div>`;
    const form=app.form(container.querySelector('[data-directory-form]'),identity+preferences+criteria,async(data,formElement)=>{
      const fd=new FormData(formElement),roles=fd.getAll('roles'),required=fd.getAll('required'),flexible=fd.getAll('flexible');if(!roles.length)throw Error('고객 역할을 하나 이상 선택해주세요.');if(required.some(key=>flexible.includes(key)))throw Error('필수와 조정 가능 조건을 구분해주세요.');if(data.moveInFrom&&data.moveInTo&&data.moveInTo<data.moveInFrom)throw Error('입주 희망 종료일은 시작일 이후여야 합니다.');
      const saved=await app.save('customers',{...current,...plainFields(data,CUSTOMER_TEXT),...numberFields(data,CUSTOMER_NUMBERS),roles,regions:split(data.regions),excludedRegions:split(data.excludedRegions),dealTypes:fd.getAll('dealTypes'),propertyTypes:fd.getAll('propertyTypes'),required,flexible},formElement);current=saved;if(isNew)offerSavedDetails(form,'customers',saved.id);return saved;
    });form.classList.add('estate-directory-form');
    on(form,'change',event=>{const input=event.target;if(!['required','flexible'].includes(input.name)||!input.checked)return;const other=form.querySelector(`input[name="${input.name==='required'?'flexible':'required'}"][value="${CSS.escape(input.value)}"]`);if(other){other.checked=false;dispatchDraft(other);}},signal);
    bindRelatedNew(container,signal);if(!isNew){relatedRows(container.querySelector('[data-related-collection="consultations"]'),'consultations',item=>item.customerId===current.id,timelineRow,signal);relatedRows(container.querySelector('[data-related-collection="proposals"]'),'proposals',item=>item.customerId===current.id,proposalRow,signal);relatedRows(container.querySelector('[data-related-collection="visits"]'),'visits',item=>array(item.customerIds).includes(current.id),visitRow,signal);relatedRows(container.querySelector('[data-related-collection="deals"]'),'deals',item=>[...array(item.sellerIds),...array(item.buyerIds)].includes(current.id),dealRow,signal);}
  }

  async function consultationPanel({container,row,isNew,signal}){
    let current={date:app.today(),priority:'normal',method:'전화',...row};
    container.innerHTML=`<div class="estate-directory-panel"><div class="estate-directory-panel-intro"><span class="estate-directory-eyebrow">CONSULTATION</span><h2>${isNew?'상담 기록 추가':'상담 기록'}</h2>${note('상담 내용과 연결 기록을 보존합니다. 다음 행동에 기한을 지정하면 후속 업무가 자동으로 연결됩니다.')}</div><div data-directory-form></div></div>`;
    const form=app.form(container.querySelector('[data-directory-form]'),section('상담 대상',relationField('customerId','고객','customers',current.customerId,true)+relationField('propertyId','매물 (선택)','properties',current.propertyId)+relationField('dealId','진행 거래 (선택)','deals',current.dealId))+section('상담 내용',field('date','상담일','date',current.date,{required:true})+field('time','상담 시간','time',current.time)+select('method','상담 방법',current.method,[['전화','전화'],['문자','문자'],['메신저','메신저'],['이메일','이메일'],['대면','대면'],['현장 방문','현장 방문'],['기타','기타']])+field('content','상담 내용','textarea',current.content,{required:true}))+section('다음 행동',field('nextAction','다음에 할 일','text',current.nextAction)+field('dueDate','후속 업무 기한','date',current.dueDate)+field('dueTime','후속 업무 시간','time',current.dueTime)+select('priority','우선순위',current.priority,PRIORITY)+note('다음 행동과 기한을 함께 저장하면 연결된 후속 업무를 생성·갱신합니다. 다음 행동 또는 기한을 지우면 해당 자동 업무를 취소합니다.')),async(data,formElement)=>{
      if(!data.customerId)throw Error('기존 고객을 선택해주세요.');if(data.dueDate&&!text(data.nextAction))throw Error('기한에 맞춰 수행할 다음 행동을 입력해주세요.');
      const saved=await app.save('consultations',{...current,...plainFields(data,'customerId propertyId dealId date time method content nextAction dueDate dueTime priority'.split(' '))},formElement);current=saved;return saved;
    });form.classList.add('estate-directory-form');bindRelations(form,signal);
  }
  async function proposalPanel({container,row,isNew,signal}){
    let current={date:app.today(),status:'suggested',...row};
    container.innerHTML=`<div class="estate-directory-panel"><div class="estate-directory-panel-intro"><span class="estate-directory-eyebrow">PROPERTY PROPOSAL</span><h2>${isNew?'매물 제안 기록':'매물 제안 상세'}</h2>${note('기존 고객과 매물을 연결하고 관심·거절 반응을 기록합니다.')}</div><div data-directory-form></div></div>`;
    const form=app.form(container.querySelector('[data-directory-form]'),section('제안 정보',relationField('customerId','고객','customers',current.customerId,true)+relationField('propertyId','매물','properties',current.propertyId,true)+field('date','제안일','date',current.date,{required:true})+select('status','반응',current.status,[['suggested','제안함'],['interested','관심 있음'],['declined','거절']])+field('notes','제안 내용 / 반응 메모','textarea',current.notes)),async(data,formElement)=>{
      if(!data.customerId||!data.propertyId)throw Error('고객과 매물을 모두 선택해주세요.');const saved=await app.save('proposals',{...current,...plainFields(data,'customerId propertyId date status notes'.split(' '))},formElement);current=saved;return saved;
    });form.classList.add('estate-directory-form');bindRelations(form,signal);
  }
  app.registerView('properties',context=>directoryView('properties',context));
  app.registerView('customers',context=>directoryView('customers',context));
  app.registerEntity('properties',propertyPanel);
  app.registerEntity('customers',customerPanel);
  app.registerEntity('consultations',consultationPanel);
  app.registerEntity('proposals',proposalPanel);
}
