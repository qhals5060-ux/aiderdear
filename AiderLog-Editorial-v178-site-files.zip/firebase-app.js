import { createConsultSync, CONSULT_KEYS } from './consult-sync-v167.js';
import {decodeArchive,encodeArchive,encodeStoredPayload} from './archive-codec-v168.js';
import {ddayFailure,ddayId,ddayScope,mergeDdaySources,resolveDdaySelection,preserveDdayRows,mutateDdayStore} from './dday-store-v174.js';
import {PRIVATE_CALENDAR_VERSION,canUsePrivateIntimacy,privateCalendarFailure,privateCalendarError,privateCalendarId,privateCalendarRange,privateCalendarRevision,normalizePrivateCalendarSettings,normalizePrivateCalendarEntry,normalizePrivateCalendarDay,privateCalendarDayMutation,privateCalendarMutation,withoutPrivateEmotionFlags} from './private-calendar-v175.js';
import {createFriendScheduleAdapter} from './friend-schedule-firebase-v175.js';
import {createAndroidSession} from './android-session-v176.js';
const storageStampV168=()=>({storageVersion:168,formatWrittenAt:serverTimestamp()});
import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import {
  browserLocalPersistence,
  indexedDBLocalPersistence,
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  reauthenticateWithPopup,
  setPersistence,
  signInWithPopup,
  signInWithCredential,
  signInWithRedirect,
  signOut,
  updateProfile,
} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import {
  Bytes,
  FieldPath,
  Timestamp,
  addDoc,
  collection,
  deleteDoc,
  deleteField,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: 'AIzaSyALzfkvB9MscSFBxz6I4mtHtCmx1G5bdaw',
  authDomain: 'aiderdear-1bbca.firebaseapp.com',
  projectId: 'aiderdear-1bbca',
  storageBucket: 'aiderdear-1bbca.firebasestorage.app',
  messagingSenderId: '272602158936',
  appId: '1:272602158936:web:4b516691f374849a52772d',
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
auth.languageCode = 'ko';

let persistenceSetupV176=null;
function prepareLoginPersistenceV176(){
  if(!persistenceSetupV176)persistenceSetupV176=(async()=>{
    try{await setPersistence(auth,browserLocalPersistence)}
    catch{try{await setPersistence(auth,indexedDBLocalPersistence)}catch{throw Object.assign(new Error('로그인 상태를 저장할 수 없습니다. 앱 또는 브라우저 저장 공간을 확인해주세요.'),{code:'auth/storage-unavailable'})}}
  })().catch(error=>{persistenceSetupV176=null;throw error});
  return persistenceSetupV176;
}
const androidSessionV176=createAndroidSession({auth,provider:GoogleAuthProvider,signInWithCredential,preparePersistence:prepareLoginPersistenceV176,bridge:()=>window.AiderLogNative,storage:{getItem:key=>window.localStorage.getItem(key),setItem:(key,value)=>window.localStorage.setItem(key,value),removeItem:key=>window.localStorage.removeItem(key)},crypto:window.crypto,
  diagnostic:detail=>console.warn('[AiderLog authentication]',detail.stage,detail.code)});

const state = {
  ready: false,
  user: null,
  pair: null,
  partner: null,
  incoming: [],
  outgoing: [],
  friends: [],
  friendIncoming: [],
  friendOutgoing: [],
  directLetters: [],
  error: '',
};

const subscribers = new Set();
let googleDriveAccessToken = '';
let googleCalendarAccessToken = '';
let unsubscribePairs = null;
let unsubscribeIncoming = null;
let unsubscribeOutgoing = null;
let unsubscribeFriends = null;
let unsubscribeFriendIncoming = null;
let unsubscribeFriendOutgoing = null;
let unsubscribeDirectLetters = null;
let unsubscribeAppData = null;
let unsubscribeOwnSchedule = null;
let unsubscribePartnerSchedule = null;
let appDataScopeKey = '';
let pairRows = [];
let incomingRows = [];
let outgoingRows = [];
let friendRows = [];
let friendIncomingRows = [];
let friendOutgoingRows = [];
let directLetterRows = [];
let repairPromise = null;
let directLetterCleanupBusy = false;

const DIRECT_LETTER_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
const PAPER_TASK_WORKSPACE_ID = 'aiderlog-paper-task-v1';
const PAPER_TASK_WORKSPACE_EMAILS = new Set(['qhals5060@gmail.com', 'aidway55@gmail.com']);

const cleanEmail = value => String(value || '').trim().toLowerCase();
const publicUser = (user, extras = {}) => user ? {
  uid: user.uid,
  email: cleanEmail(user.email),
  name: String(user.displayName || user.email?.split('@')[0] || '사용자'),
  photoURL: String(user.photoURL || ''),
  gender: ['female', 'male'].includes(extras.gender) ? extras.gender : '',
  birthDate: /^\d{4}-\d{2}-\d{2}$/.test(String(extras.birthDate || '')) ? String(extras.birthDate) : '',
  birthCalendar: extras.birthCalendar === 'lunar' ? 'lunar' : 'solar',
  birthLeap: Boolean(extras.birthLeap),
} : null;
const timestampValue = value => value?.toMillis?.() || Number(value || 0);
const plainDoc = snapshot => snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null;
const publicStateUserV175 = () => state.user ? {...state.user,emailVerified:auth.currentUser?.uid === state.user.uid && auth.currentUser.emailVerified === true} : null;

function emit() {
  const snapshot = {
    ready: state.ready,
    user: publicStateUserV175(),
    pair: state.pair ? { ...state.pair } : null,
    partner: state.partner ? { ...state.partner } : null,
    incoming: state.incoming.map(row => ({ ...row })),
    outgoing: state.outgoing.map(row => ({ ...row })),
    friends: state.friends.map(row => ({ ...row })),
    friendIncoming: state.friendIncoming.map(row => ({ ...row })),
    friendOutgoing: state.friendOutgoing.map(row => ({ ...row })),
    directLetters: state.directLetters.map(row => ({ ...row })),
    error: state.error,
  };
  subscribers.forEach(callback => {
    try { callback(snapshot); } catch (error) { console.error(error); }
  });
  window.dispatchEvent(new CustomEvent('aiderdear-firebase-state', { detail: snapshot }));
}

function stopListeners() {
  [unsubscribePairs, unsubscribeIncoming, unsubscribeOutgoing, unsubscribeFriends, unsubscribeFriendIncoming, unsubscribeFriendOutgoing, unsubscribeDirectLetters, unsubscribeAppData, unsubscribeOwnSchedule, unsubscribePartnerSchedule].forEach(stop => {
    try { stop?.(); } catch {}
  });
  unsubscribePairs = unsubscribeIncoming = unsubscribeOutgoing = unsubscribeFriends = unsubscribeFriendIncoming = unsubscribeFriendOutgoing = unsubscribeDirectLetters = unsubscribeAppData = unsubscribeOwnSchedule = unsubscribePartnerSchedule = null;
  appDataScopeKey = '';
  pairRows = [];
  incomingRows = [];
  outgoingRows = [];
  friendRows = [];
  friendIncomingRows = [];
  friendOutgoingRows = [];
  directLetterRows = [];
}

function watchAppData() {
  if (!state.user) return;
  const scopeKey = `${state.user.uid}:${state.pair?.id || 'solo'}`;
  if (scopeKey === appDataScopeKey) return;
  try { unsubscribeAppData?.(); } catch {}
  appDataScopeKey = scopeKey;
  const ref = state.pair
    ? doc(db, 'pairs', state.pair.id, 'app', 'main')
    : doc(db, 'users', state.user.uid, 'app', 'main');
  unsubscribeAppData = onSnapshot(ref, snapshot => {
    if (!snapshot.exists()) return;
    const data = snapshot.data();
    window.dispatchEvent(new CustomEvent('aiderdear-firebase-data', {
      detail: {
        scope: scopeKey,
        updatedBy: String(data.updatedBy || ''),
        updatedAt: timestampValue(data.updatedAt),
      },
    }));
  }, error => {
    state.error = error.message;
    emit();
  });
}

function recomputeState() {
  const active = pairRows
    .filter(row => row.status === 'active' && Array.isArray(row.memberUids) && row.memberUids.includes(state.user?.uid))
    .sort((a, b) => timestampValue(b.createdAt) - timestampValue(a.createdAt))[0] || null;
  state.pair = active;
  state.partner = null;
  if (active && state.user) {
    const profiles = Array.isArray(active.memberProfiles) ? active.memberProfiles : [];
    const partner = profiles.find(profile => profile.uid && profile.uid !== state.user.uid);
    if (partner) state.partner = {
      uid: String(partner.uid || ''),
      email: cleanEmail(partner.email),
      name: String(partner.name || partner.email?.split('@')[0] || '상대'),
      photoURL: String(partner.photoURL || ''),
      gender: ['female', 'male'].includes(partner.gender) ? partner.gender : '',
      birthDate: /^\d{4}-\d{2}-\d{2}$/.test(String(partner.birthDate || '')) ? String(partner.birthDate) : '',
      birthCalendar: partner.birthCalendar === 'lunar' ? 'lunar' : 'solar',
      birthLeap: Boolean(partner.birthLeap),
    };
  }
  state.incoming = incomingRows
    .filter(row => row.status === 'pending')
    .sort((a, b) => timestampValue(b.createdAt) - timestampValue(a.createdAt));
  state.outgoing = outgoingRows
    .filter(row => row.status === 'pending')
    .sort((a, b) => timestampValue(b.createdAt) - timestampValue(a.createdAt));
  state.friends = friendRows
    .filter(row => row.status === 'active' && row.memberUids?.includes(state.user?.uid))
    .map(row => {
      const friend = (row.memberProfiles || []).find(profile => profile.uid !== state.user?.uid) || {};
      return { friendshipId: row.id, uid: String(friend.uid || ''), email: cleanEmail(friend.email), name: String(friend.name || friend.email?.split('@')[0] || '친구'), photoURL: String(friend.photoURL || ''), gender: ['female', 'male'].includes(friend.gender) ? friend.gender : '', birthDate: /^\d{4}-\d{2}-\d{2}$/.test(String(friend.birthDate || '')) ? String(friend.birthDate) : '', birthCalendar: friend.birthCalendar === 'lunar' ? 'lunar' : 'solar', birthLeap: Boolean(friend.birthLeap) };
    })
    .filter(row => row.uid && row.email)
    .sort((a, b) => a.name.localeCompare(b.name, 'ko'));
  state.friendIncoming = friendIncomingRows.filter(row => row.status === 'pending').sort((a, b) => timestampValue(b.createdAt) - timestampValue(a.createdAt));
  state.friendOutgoing = friendOutgoingRows.filter(row => row.status === 'pending').sort((a, b) => timestampValue(b.createdAt) - timestampValue(a.createdAt));
  state.directLetters = directLetterRows.sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
  watchAppData();
  emit();
}

async function cleanupExpiredDirectLetters(snapshots) {
  if (directLetterCleanupBusy || !snapshots.length) return;
  directLetterCleanupBusy = true;
  try {
    for (let start = 0; start < snapshots.length; start += 400) {
      const batch = writeBatch(db);
      snapshots.slice(start, start + 400).forEach(snapshot => batch.delete(snapshot.ref));
      await batch.commit();
    }
  } finally {
    directLetterCleanupBusy = false;
  }
}

async function ensureUserProfile(user) {
  const ref = doc(db, 'users', user.uid);
  const saved = plainDoc(await getDoc(ref)) || {};
  const profile = publicUser(user, saved);
  await setDoc(ref, {
    ...profile,
    updatedAt: serverTimestamp(),
  }, { merge: true });
  return profile;
}

async function propagateMemberProfile(profile) {
  const sources = await Promise.all([
    getDocs(query(collection(db, 'pairs'), where('memberUids', 'array-contains', profile.uid))),
    getDocs(query(collection(db, 'friendships'), where('memberUids', 'array-contains', profile.uid))),
  ]);
  const rows = sources.flatMap(snapshot => snapshot.docs)
    .filter(snapshot => snapshot.data().status === 'active');
  for (let start = 0; start < rows.length; start += 400) {
    const batch = writeBatch(db);
    let changed = 0;
    rows.slice(start, start + 400).forEach(snapshot => {
      const data = snapshot.data();
      const memberProfiles = Array.isArray(data.memberProfiles) && data.memberProfiles.length === 2
        ? data.memberProfiles.map(member => member.uid === profile.uid ? {
            ...member,
            name: profile.name,
            gender: profile.gender,
            birthDate: profile.birthDate,
            birthCalendar: profile.birthCalendar,
            birthLeap: profile.birthLeap,
          } : member)
        : [];
      if (!memberProfiles.some(member => member.uid === profile.uid)) return;
      batch.update(snapshot.ref, { memberProfiles, updatedAt: serverTimestamp() });
      changed += 1;
    });
    if (changed) await batch.commit();
  }
}

async function updateNickname(rawName) {
  const user = auth.currentUser;
  if (!user) throw new Error('로그인이 필요합니다.');
  const name = String(rawName || '').trim().slice(0, 24);
  if (!name) throw new Error('사용할 닉네임을 입력해주세요.');
  await updateProfile(user, { displayName: name });
  state.user = await ensureUserProfile(user);
  await propagateMemberProfile(state.user);
  emit();
  return state.user;
}

async function updateProfileSettings(raw = {}) {
  const user = auth.currentUser;
  if (!user) throw new Error('로그인이 필요합니다.');
  const name = String(raw.name || user.displayName || '').trim().slice(0, 24);
  const gender = ['female', 'male'].includes(raw.gender) ? raw.gender : '';
  const birthDate = /^\d{4}-\d{2}-\d{2}$/.test(String(raw.birthDate || '')) ? String(raw.birthDate) : '';
  const birthCalendar = raw.birthCalendar === 'lunar' ? 'lunar' : 'solar';
  const birthLeap = birthCalendar === 'lunar' && Boolean(raw.birthLeap);
  if (!name) throw new Error('사용할 닉네임을 입력해주세요.');
  if (!gender) throw new Error('성별을 선택해주세요.');
  if (!birthDate) throw new Error('생년월일을 입력해주세요.');
  if (name !== user.displayName) await updateProfile(user, { displayName: name });
  const profile = publicUser(user, { gender, birthDate, birthCalendar, birthLeap });
  await setDoc(doc(db, 'users', user.uid), { ...profile, updatedAt: serverTimestamp() }, { merge: true });
  state.user = profile;
  await propagateMemberProfile(profile);
  emit();
  return { ...profile };
}

function startListeners(user) {
  stopListeners();
  const email = cleanEmail(user.email);
  unsubscribePairs = onSnapshot(
    query(collection(db, 'pairs'), where('memberUids', 'array-contains', user.uid)),
    snapshot => {
      pairRows = snapshot.docs.map(plainDoc);
      recomputeState();
    },
    error => {
      state.error = error.message;
      emit();
    },
  );
  unsubscribeIncoming = onSnapshot(
    query(collection(db, 'pairInvites'), where('toEmail', '==', email)),
    snapshot => {
      incomingRows = snapshot.docs.map(plainDoc);
      recomputeState();
    },
    error => {
      state.error = error.message;
      emit();
    },
  );
  unsubscribeOutgoing = onSnapshot(
    query(collection(db, 'pairInvites'), where('fromUid', '==', user.uid)),
    snapshot => {
      outgoingRows = snapshot.docs.map(plainDoc);
      recomputeState();
    },
    error => {
      state.error = error.message;
      emit();
    },
  );
  unsubscribeFriends = onSnapshot(
    query(collection(db, 'friendships'), where('memberUids', 'array-contains', user.uid)),
    snapshot => { friendRows = snapshot.docs.map(plainDoc); recomputeState(); },
    error => { state.error = error.message; emit(); },
  );
  unsubscribeFriendIncoming = onSnapshot(
    query(collection(db, 'friendInvites'), where('toEmail', '==', email)),
    snapshot => { friendIncomingRows = snapshot.docs.map(plainDoc); recomputeState(); },
    error => { state.error = error.message; emit(); },
  );
  unsubscribeFriendOutgoing = onSnapshot(
    query(collection(db, 'friendInvites'), where('fromUid', '==', user.uid)),
    snapshot => { friendOutgoingRows = snapshot.docs.map(plainDoc); recomputeState(); },
    error => { state.error = error.message; emit(); },
  );
  unsubscribeDirectLetters = onSnapshot(
    query(collection(db, 'directLetters'), where('memberUids', 'array-contains', user.uid)),
    snapshot => {
      const cutoff = Date.now() - DIRECT_LETTER_RETENTION_MS;
      const expired = snapshot.docs.filter(item => {
        const createdAt = timestampValue(item.data().createdAt);
        return createdAt > 0 && createdAt < cutoff;
      });
      directLetterRows = snapshot.docs.filter(item => !expired.includes(item)).map(item => {
        const row = plainDoc(item) || {};
        let photoDataUrl = '';
        try { if (row.photoBytes?.toBase64) photoDataUrl = `data:${row.photoMimeType || 'image/jpeg'};base64,${row.photoBytes.toBase64()}`; } catch {}
        const photoDataUrls = [photoDataUrl, ...(Array.isArray(row.additionalPhotos) ? row.additionalPhotos.slice(0, 5).map(photo => { try { return photo.photoBytes?.toBase64 ? `data:${photo.photoMimeType || 'image/jpeg'};base64,${photo.photoBytes.toBase64()}` : ''; } catch { return ''; } }) : [])].filter(Boolean);
        return { ...row, transport: 'direct', photoDataUrl, photoDataUrls, createdAt: timestampValue(row.createdAt) };
      });
      recomputeState();
      if (expired.length) cleanupExpiredDirectLetters(expired).catch(error => console.warn('Expired letter cleanup failed', error));
    },
    error => { state.error = error.message; emit(); },
  );
}

function requireUser() {
  if (!auth.currentUser || !state.user) throw new Error('Google 로그인이 필요합니다.');
  return state.user;
}

function requirePaperTaskMember() {
  const user = requireUser();
  if (!PAPER_TASK_WORKSPACE_EMAILS.has(cleanEmail(user.email))) {
    throw new Error('PAPER · TASK 공동 작업공간에 접근할 수 없는 계정입니다.');
  }
  return user;
}

function paperTaskWorkspaceRef() {
  requirePaperTaskMember();
  return doc(db, 'sharedWorkspaces', PAPER_TASK_WORKSPACE_ID);
}

function paperAnalysisDocumentId(paperId) {
  const value = String(paperId || '').trim();
  if (!value) throw new Error('논문 ID가 필요합니다.');
  const bytes = new TextEncoder().encode(value);
  let binary = '';
  bytes.forEach(byte => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '').slice(0, 900);
}

function paperAnalysisRef(paperId) {
  requirePaperTaskMember();
  return doc(db, 'sharedWorkspaces', PAPER_TASK_WORKSPACE_ID, 'paperAnalyses', paperAnalysisDocumentId(paperId));
}

function pairScope() {
  const user = requireUser();
  return state.pair
    ? { kind: 'pair', id: state.pair.id, base: ['pairs', state.pair.id] }
    : { kind: 'user', id: user.uid, base: ['users', user.uid] };
}

function scopedDoc(section, id = 'main') {
  const scope = pairScope();
  return doc(db, ...scope.base, section, id);
}

async function login() {
  state.error = '';
  if(androidSessionV176.enabled())return androidSessionV176.begin();
  await prepareLoginPersistenceV176();
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  try {
    return await signInWithPopup(auth, provider);
  } catch (error) {
    if (['auth/popup-blocked', 'auth/operation-not-supported-in-this-environment', 'auth/web-storage-unsupported'].includes(error.code)) {
      await signInWithRedirect(auth, provider);
      return null;
    }
    if (error?.code === 'auth/unauthorized-domain') {
      throw new Error('현재 주소가 Firebase 승인 도메인에 등록되지 않았습니다. Firebase Authentication의 승인된 도메인에 이 사이트 주소를 추가해주세요.');
    }
    if (error?.code === 'auth/popup-closed-by-user') {
      throw new Error('로그인 창이 닫혔습니다. 다시 로그인해주세요.');
    }
    throw error;
  }
}

async function logout() {
  await androidSessionV176.cancel();
  googleDriveAccessToken = '';
  googleCalendarAccessToken = '';
  await signOut(auth);
}

function googleDriveProvider() {
  const provider = new GoogleAuthProvider();
  provider.addScope('https://www.googleapis.com/auth/drive.file');
  provider.setCustomParameters({ prompt: 'consent' });
  return provider;
}

async function requestGoogleDriveAccess() {
  requireUser();
  const result = await reauthenticateWithPopup(auth.currentUser, googleDriveProvider());
  const credential = GoogleAuthProvider.credentialFromResult(result);
  googleDriveAccessToken = String(credential?.accessToken || '');
  if (!googleDriveAccessToken) throw new Error('Google Drive 연결 권한을 확인하지 못했습니다.');
  return true;
}

async function googleDriveFetch(url, options = {}, responseType = 'json') {
  if (!googleDriveAccessToken) await requestGoogleDriveAccess();
  const headers = new Headers(options.headers || {});
  headers.set('Authorization', `Bearer ${googleDriveAccessToken}`);
  const response = await fetch(url, { ...options, headers });
  if (!response.ok) {
    const body = await response.text().catch(() => '');
    if (response.status === 401) googleDriveAccessToken = '';
    if (response.status === 403 && /accessNotConfigured|SERVICE_DISABLED/i.test(body)) {
      throw new Error('Google Cloud에서 Google Drive API를 먼저 사용 설정해주세요.');
    }
    throw new Error(`Google Drive 백업 오류 (${response.status})`);
  }
  if (response.status === 204) return null;
  if (responseType === 'response') return response;
  if (responseType === 'text') return response.text();
  return response.json();
}

function googleCalendarProvider() {
  const provider = new GoogleAuthProvider();
  provider.addScope('https://www.googleapis.com/auth/calendar.readonly');
  // Keep the proven v100 browser-side Calendar authorization flow. This
  // returns the Calendar access token directly to the signed-in app without
  // making the server OAuth callback a prerequisite for connecting.
  provider.setCustomParameters({ prompt: 'consent' });
  return provider;
}

async function requestGoogleCalendarAccess() {
  requireUser();
  try {
    console.info('[calendar-connection] browser-consent-start');
    const result = await reauthenticateWithPopup(auth.currentUser, googleCalendarProvider());
    const credential = GoogleAuthProvider.credentialFromResult(result);
    googleCalendarAccessToken = String(credential?.accessToken || '');
    if (!googleCalendarAccessToken) throw new Error('Google Calendar 연결 권한을 확인하지 못했습니다.');
    console.info('[calendar-connection] browser-consent-ready');
    return true;
  } catch (error) {
    console.warn('[calendar-connection] browser-consent-failed', error?.code || error?.message || String(error));
    if (error?.code === 'auth/popup-closed-by-user') {
      throw new Error('AiderLog 로그인은 완료되어 있습니다. Google Calendar 권한 연결만 취소되었습니다.');
    }
    if (error?.code === 'auth/unauthorized-domain') {
      throw new Error('AiderLog 로그인은 완료되어 있습니다. Google Calendar OAuth 승인 도메인 설정을 확인해주세요.');
    }
    throw error;
  }
}

async function googleCalendarFetch(url, options = {}) {
  if (!googleCalendarAccessToken) await requestGoogleCalendarAccess();
  const headers = new Headers(options.headers || {});
  headers.set('Authorization', `Bearer ${googleCalendarAccessToken}`);
  const response = await fetch(url, { ...options, headers });
  if (!response.ok) {
    const body = await response.text().catch(() => '');
    if (response.status === 401) googleCalendarAccessToken = '';
    if (response.status === 403 && /accessNotConfigured|SERVICE_DISABLED/i.test(body)) {
      throw new Error('Google Cloud에서 Google Calendar API를 먼저 사용 설정해주세요.');
    }
    throw new Error(`Google Calendar 가져오기 오류 (${response.status})`);
  }
  return response.status === 204 ? null : response.json();
}

async function listGoogleCalendars() {
  const fields = 'items(id,summary,primary,accessRole,backgroundColor,foregroundColor)';
  const result = await googleCalendarFetch(`https://www.googleapis.com/calendar/v3/users/me/calendarList?maxResults=250&fields=${encodeURIComponent(fields)}`);
  return Array.isArray(result?.items) ? result.items : [];
}

async function listGoogleCalendarEvents(calendarId, timeMin, timeMax) {
  const rows = [];
  let pageToken = '';
  do {
    const params = new URLSearchParams({
      singleEvents: 'true',
      orderBy: 'startTime',
      maxResults: '2500',
      timeMin,
      timeMax,
      fields: 'items(id,status,summary,description,start,end,updated,htmlLink),nextPageToken',
    });
    if (pageToken) params.set('pageToken', pageToken);
    const result = await googleCalendarFetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events?${params}`);
    rows.push(...(Array.isArray(result?.items) ? result.items.filter(item => item.status !== 'cancelled') : []));
    pageToken = String(result?.nextPageToken || '');
  } while (pageToken && rows.length < 750);
  return rows.slice(0, 750);
}

function driveQueryEscape(value) {
  return String(value || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

async function ensureGoogleDriveBackupFolder() {
  const q = "mimeType='application/vnd.google-apps.folder' and trashed=false and appProperties has { key='aiderlogBackup' and value='root' }";
  const result = await googleDriveFetch(`https://www.googleapis.com/drive/v3/files?spaces=drive&pageSize=10&fields=files(id,name)&q=${encodeURIComponent(q)}`);
  if (result.files?.[0]) return result.files[0];
  return googleDriveFetch('https://www.googleapis.com/drive/v3/files?fields=id,name', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'AiderLog Backups',
      mimeType: 'application/vnd.google-apps.folder',
      appProperties: { aiderlogBackup: 'root' },
    }),
  });
}

async function findGoogleDriveBackup(sourceId) {
  const safe = driveQueryEscape(sourceId);
  const q = `trashed=false and appProperties has { key='aiderlogSourceId' and value='${safe}' }`;
  const result = await googleDriveFetch(`https://www.googleapis.com/drive/v3/files?spaces=drive&pageSize=1&fields=files(id,name,size,mimeType)&q=${encodeURIComponent(q)}`);
  return result.files?.[0] || null;
}

async function uploadGoogleDriveBackupFile(folderId, sourceId, name, blob) {
  const existing = await findGoogleDriveBackup(sourceId);
  if (existing) return { ...existing, reused: true };
  const metadata = {
    name: String(name || 'AiderLog media').replace(/[\\/:*?"<>|]/g, '_').slice(0, 180),
    parents: [folderId],
    mimeType: blob.type || 'application/octet-stream',
    appProperties: { aiderlogBackup: 'media', aiderlogSourceId: String(sourceId) },
  };
  const start = await googleDriveFetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,size,mimeType', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      'X-Upload-Content-Type': blob.type || 'application/octet-stream',
      'X-Upload-Content-Length': String(blob.size),
    },
    body: JSON.stringify(metadata),
  }, 'response');
  const uploadUrl = start.headers.get('Location');
  if (!uploadUrl) throw new Error('Google Drive 업로드 주소를 받지 못했습니다.');
  return googleDriveFetch(uploadUrl, {
    method: 'PUT',
    headers: { 'Content-Type': blob.type || 'application/octet-stream' },
    body: blob,
  });
}

async function uploadGoogleDriveBackupManifest(folderId, fileName, payload) {
  const boundary = `aiderlog_backup_${Date.now()}`;
  const metadata = JSON.stringify({
    name: fileName,
    parents: [folderId],
    mimeType: 'application/json',
    appProperties: { aiderlogBackup: 'manifest' },
  });
  const body = new Blob([
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n`,
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(payload, null, 2)}\r\n`,
    `--${boundary}--`,
  ], { type: `multipart/related; boundary=${boundary}` });
  return googleDriveFetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size', {
    method: 'POST',
    headers: { 'Content-Type': `multipart/related; boundary=${boundary}` },
    body,
  });
}

async function backupEventDataToGoogleDrive({ records = [], travel = [], media = [], exportedAt = '' } = {}) {
  requireUser();
  await requestGoogleDriveAccess();
  const folder = await ensureGoogleDriveBackupFolder();
  const mediaBackups = {};
  let uploaded = 0;
  for (const item of media) {
    const id = String(item?.id || '');
    if (!id || mediaBackups[id]) continue;
    const blob = await readMedia(id);
    const result = await uploadGoogleDriveBackupFile(folder.id, id, item.name || id, blob);
    mediaBackups[id] = { driveFileId: result.id, name: result.name, mimeType: result.mimeType || blob.type, size: Number(result.size || blob.size) };
    if (!result.reused) uploaded += 1;
  }
  const date = String(exportedAt || new Date().toISOString()).slice(0, 10);
  const manifest = await uploadGoogleDriveBackupManifest(folder.id, `AiderLog-Event-Backup-${date}.json`, {
    app: 'AiderLog',
    version: 1,
    exportedAt: exportedAt || new Date().toISOString(),
    records,
    travel,
    mediaBackups,
  });
  return { folderId: folder.id, manifestId: manifest.id, mediaCount: Object.keys(mediaBackups).length, uploaded };
}

async function backupPaperTaskDataToGoogleDrive({ paper = {}, task = {}, media = [], exportedAt = '' } = {}) {
  requireUser();
  await requestGoogleDriveAccess();
  const folder = await ensureGoogleDriveBackupFolder();
  const mediaBackups = {};
  let uploaded = 0;
  for (const item of media) {
    const id = String(item?.id || '');
    if (!id || mediaBackups[id]) continue;
    const blob = item?.storageScope === 'paper-task' ? await readPaperTaskMedia(id) : await readPrivateMedia(id);
    const result = await uploadGoogleDriveBackupFile(folder.id, `private:${id}`, item.name || id, blob);
    mediaBackups[id] = { driveFileId: result.id, name: result.name, mimeType: result.mimeType || blob.type, size: Number(result.size || blob.size) };
    if (!result.reused) uploaded += 1;
  }
  const date = String(exportedAt || new Date().toISOString()).slice(0, 10);
  const manifest = await uploadGoogleDriveBackupManifest(folder.id, `AiderLog-Paper-Task-Backup-${date}.json`, {
    app: 'AiderLog',
    version: 1,
    exportedAt: exportedAt || new Date().toISOString(),
    paper,
    task,
    mediaBackups,
  });
  return { folderId: folder.id, manifestId: manifest.id, mediaCount: Object.keys(mediaBackups).length, uploaded };
}

async function createInvite(rawEmail) {
  const user = requireUser();
  const toEmail = cleanEmail(rawEmail);
  if (!toEmail || !toEmail.includes('@')) throw new Error('상대의 Google 이메일을 정확히 입력해주세요.');
  if (toEmail === user.email) throw new Error('본인에게는 초대를 보낼 수 없습니다.');
  if (state.pair) throw new Error('이미 커플로 연결되어 있습니다.');
  if (state.outgoing.some(row => cleanEmail(row.toEmail) === toEmail && row.status === 'pending')) {
    throw new Error('이미 이 이메일로 보낸 초대가 있습니다.');
  }
  const ref = await addDoc(collection(db, 'pairInvites'), {
    fromUid: user.uid,
    fromEmail: user.email,
    fromName: user.name,
    fromPhotoURL: user.photoURL,
    fromGender: user.gender,
    fromBirthDate: user.birthDate,
    fromBirthCalendar: user.birthCalendar,
    fromBirthLeap: user.birthLeap,
    toEmail,
    status: 'pending',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

async function finalizeInvitePair(invite, user, updateInvite = true) {
  const inviteId = String(invite?.id || '');
  if (!inviteId || !invite?.fromUid) throw new Error('커플 요청 정보를 확인할 수 없습니다.');
  const pairRef = doc(db, 'pairs', inviteId);
  const memberUids = [invite.fromUid, user.uid];
  const batch = writeBatch(db);
  if (updateInvite) batch.update(doc(db, 'pairInvites', inviteId), {
    status: 'accepted',
    pairId: inviteId,
    updatedAt: serverTimestamp(),
  });
  batch.set(pairRef, {
    inviteId,
    status: 'active',
    memberUids,
    memberEmails: [cleanEmail(invite.fromEmail), user.email],
    memberProfiles: [
      {
        uid: invite.fromUid,
        email: cleanEmail(invite.fromEmail),
        name: String(invite.fromName || invite.fromEmail?.split('@')[0] || '상대'),
        photoURL: String(invite.fromPhotoURL || ''),
        gender: ['female', 'male'].includes(invite.fromGender) ? invite.fromGender : '',
        birthDate: /^\d{4}-\d{2}-\d{2}$/.test(String(invite.fromBirthDate || '')) ? String(invite.fromBirthDate) : '',
        birthCalendar: invite.fromBirthCalendar === 'lunar' ? 'lunar' : 'solar',
        birthLeap: Boolean(invite.fromBirthLeap),
      },
      { ...user },
    ],
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  memberUids.forEach(uid => batch.set(doc(db, 'pairMemberships', uid), {
    uid,
    pairId: inviteId,
    memberUids,
    status: 'active',
    createdAt: serverTimestamp(),
  }));
  try {
    await batch.commit();
  } catch (error) {
    if (error.code === 'permission-denied') {
      throw new Error('커플 연결을 완료할 수 없습니다. 나 또는 상대가 이미 다른 커플과 연결되어 있는지 확인해주세요.');
    }
    throw error;
  }
  return inviteId;
}

async function acceptInvite(inviteId) {
  const user = requireUser();
  if (state.pair) throw new Error('이미 커플로 연결되어 있습니다.');
  const invite = plainDoc(await getDoc(doc(db, 'pairInvites', inviteId)));
  if (!invite || invite.status !== 'pending') throw new Error('이미 처리되었거나 만료된 초대입니다.');
  if (cleanEmail(invite.toEmail) !== user.email) throw new Error('이 계정으로 받은 초대가 아닙니다.');
  return finalizeInvitePair(invite, user, true);
}

async function repairPairConnection() {
  if (repairPromise) return repairPromise;
  repairPromise = (async () => {
    const user = requireUser();
    const pairSnapshot = await getDocs(query(collection(db, 'pairs'), where('memberUids', 'array-contains', user.uid)));
    const visiblePairs = pairSnapshot.docs.map(plainDoc);
    const active = visiblePairs.find(row => row.status === 'active' && row.memberUids?.includes(user.uid));
    if (active) {
      pairRows = visiblePairs;
      recomputeState();
      return true;
    }
    const inviteSnapshot = await getDocs(query(collection(db, 'pairInvites'), where('toEmail', '==', user.email)));
    const accepted = inviteSnapshot.docs.map(plainDoc)
      .filter(row => row.status === 'accepted' && row.pairId === row.id)
      .sort((a, b) => timestampValue(b.updatedAt || b.createdAt) - timestampValue(a.updatedAt || a.createdAt));
    for (const invite of accepted) {
      const pair = plainDoc(await getDoc(doc(db, 'pairs', invite.id)));
      if (pair?.status === 'active' && pair.memberUids?.includes(user.uid)) {
        pairRows = [pair, ...visiblePairs.filter(row => row.id !== pair.id)];
        recomputeState();
        return true;
      }
      if (!pair) {
        await finalizeInvitePair(invite, user, false);
        return true;
      }
    }
    return false;
  })();
  try { return await repairPromise; } finally { repairPromise = null; }
}

async function rejectInvite(inviteId) {
  requireUser();
  await updateDoc(doc(db, 'pairInvites', inviteId), {
    status: 'rejected',
    updatedAt: serverTimestamp(),
  });
}

async function cancelInvite(inviteId) {
  requireUser();
  await updateDoc(doc(db, 'pairInvites', inviteId), {
    status: 'cancelled',
    updatedAt: serverTimestamp(),
  });
}

async function disconnectPair() {
  const user = requireUser();
  if (!state.pair) return;
  const batch = writeBatch(db);
  batch.update(doc(db, 'pairs', state.pair.id), {
    status: 'disconnected',
    disconnectedBy: user.uid,
    updatedAt: serverTimestamp(),
  });
  state.pair.memberUids.forEach(uid => batch.delete(doc(db, 'pairMemberships', uid)));
  await batch.commit();
}

async function createFriendInvite(rawEmail) {
  const user = requireUser();
  const toEmail = cleanEmail(rawEmail);
  if (!toEmail || !toEmail.includes('@')) throw new Error('친구의 Google 이메일을 정확히 입력해주세요.');
  if (toEmail === user.email) throw new Error('본인에게는 친구 요청을 보낼 수 없습니다.');
  if (state.friends.some(row => row.email === toEmail)) throw new Error('이미 친구로 연결되어 있습니다.');
  if (state.friendOutgoing.some(row => cleanEmail(row.toEmail) === toEmail && row.status === 'pending')) throw new Error('이미 보낸 친구 요청이 있습니다.');
  const ref = await addDoc(collection(db, 'friendInvites'), {
    fromUid: user.uid,
    fromEmail: user.email,
    fromName: user.name,
    fromPhotoURL: user.photoURL,
    fromGender: user.gender,
    fromBirthDate: user.birthDate,
    fromBirthCalendar: user.birthCalendar,
    fromBirthLeap: user.birthLeap,
    toEmail,
    status: 'pending',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

async function acceptFriendInvite(inviteId) {
  const user = requireUser();
  const invite = plainDoc(await getDoc(doc(db, 'friendInvites', inviteId)));
  if (!invite || invite.status !== 'pending') throw new Error('이미 처리되었거나 만료된 친구 요청입니다.');
  if (cleanEmail(invite.toEmail) !== user.email) throw new Error('이 계정으로 받은 친구 요청이 아닙니다.');
  const batch = writeBatch(db);
  batch.update(doc(db, 'friendInvites', inviteId), { status: 'accepted', friendshipId: inviteId, updatedAt: serverTimestamp() });
  batch.set(doc(db, 'friendships', inviteId), {
    inviteId,
    status: 'active',
    memberUids: [invite.fromUid, user.uid],
    memberEmails: [cleanEmail(invite.fromEmail), user.email],
    memberProfiles: [
      { uid: invite.fromUid, email: cleanEmail(invite.fromEmail), name: String(invite.fromName || invite.fromEmail?.split('@')[0] || '친구'), photoURL: String(invite.fromPhotoURL || ''), gender: ['female', 'male'].includes(invite.fromGender) ? invite.fromGender : '', birthDate: /^\d{4}-\d{2}-\d{2}$/.test(String(invite.fromBirthDate || '')) ? String(invite.fromBirthDate) : '', birthCalendar: invite.fromBirthCalendar === 'lunar' ? 'lunar' : 'solar', birthLeap: Boolean(invite.fromBirthLeap) },
      { ...user },
    ],
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  await batch.commit();
  return inviteId;
}

async function rejectFriendInvite(inviteId) {
  requireUser();
  await updateDoc(doc(db, 'friendInvites', inviteId), { status: 'rejected', updatedAt: serverTimestamp() });
}

async function cancelFriendInvite(inviteId) {
  requireUser();
  await updateDoc(doc(db, 'friendInvites', inviteId), { status: 'cancelled', updatedAt: serverTimestamp() });
}

async function removeFriend(friendshipId) {
  const user = requireUser();
  const row = plainDoc(await getDoc(doc(db, 'friendships', friendshipId)));
  if (!row?.memberUids?.includes(user.uid)) throw new Error('친구 연결을 확인할 수 없습니다.');
  await deleteDoc(doc(db, 'friendships', friendshipId));
}

function directPhotoPayload(dataUrl) {
  const match = String(dataUrl || '').match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return {};
  if (match[2].length > 680000) throw new Error('사진 용량이 큽니다. 다른 사진을 선택해주세요.');
  return { photoMimeType: match[1], photoBytes: Bytes.fromBase64String(match[2]) };
}

function directPhotosPayload(photoDataUrls, photoDataUrl) {
  const urls = Array.isArray(photoDataUrls) ? photoDataUrls : (photoDataUrl ? [photoDataUrl] : []);
  if (urls.length > 6 || urls.reduce((sum, url) => sum + String(url).length, 0) > 900000) throw new Error('편지에는 압축된 사진을 최대 6장까지 첨부할 수 있습니다.');
  const photos = urls.map(url => { const photo = directPhotoPayload(url); if (!photo.photoBytes) throw new Error('사진 형식을 확인해주세요.'); return photo; });
  return photos.length ? { ...photos[0], ...(photos.length > 1 ? { additionalPhotos: photos.slice(1) } : {}) } : {};
}

async function sendDirectLetter({ toUid, toEmail, toName, body, photoDataUrl = '', photoDataUrls } = {}) {
  const user = requireUser();
  const friend = state.friends.find(row => row.uid === toUid && row.email === cleanEmail(toEmail));
  const partner = state.partner?.uid === toUid && state.partner?.email === cleanEmail(toEmail);
  if (!friend && !partner) throw new Error('연결된 커플 또는 친구에게만 편지를 보낼 수 있습니다.');
  const text = String(body || '').trim().slice(0, 220);
  if (!text) throw new Error('편지 내용을 입력해주세요.');
  const payload = {
    fromUid: user.uid,
    fromEmail: user.email,
    fromName: user.name,
    toUid: String(toUid),
    toEmail: cleanEmail(toEmail),
    toName: String(toName || toEmail?.split('@')[0] || '받는 사람').slice(0, 80),
    memberUids: [user.uid, String(toUid)],
    connectionType: friend ? 'friend' : 'pair',
    connectionId: friend ? friend.friendshipId : state.pair?.id,
    body: text,
    readBy: [user.uid],
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    ...directPhotosPayload(photoDataUrls, photoDataUrl),
  };
  return (await addDoc(collection(db, 'directLetters'), payload)).id;
}

async function markDirectLetterRead(letterId) {
  const user = requireUser();
  const ref = doc(db, 'directLetters', letterId);
  const row = plainDoc(await getDoc(ref));
  if (!row || row.toUid !== user.uid) return;
  const readBy = Array.isArray(row.readBy) ? row.readBy : [];
  if (readBy.includes(user.uid)) return;
  await updateDoc(ref, { readBy: [...readBy, user.uid], updatedAt: serverTimestamp() });
}

async function readAppData() {
  const snapshot = await getDoc(scopedDoc('app'));
  return snapshot.exists() ? decodeArchive(snapshot.data().payload) || null : null;
}

// D-days have their own documents: a stale full app/main save cannot erase them.
// Only the signed-in user's and their currently active pair's legacy data is read.
function captureDdayContext() {
  const user = requireUser(), uid = String(user.uid), pairId = String(state.pair?.id || '');
  ddayId(uid); if (pairId) ddayId(pairId);
  const context = {uid, pairId, email: cleanEmail(user.email), partnerEmail: cleanEmail(state.partner?.email), pairKey: eventPairKey()};
  assertDdayContext(context); return context;
}
function assertDdayContext(context) {
  if (state.user?.uid !== context.uid || auth.currentUser?.uid !== context.uid || String(state.pair?.id || '') !== context.pairId) ddayFailure('로그인 계정 또는 커플 연결이 변경되어 D-day 작업을 중단했습니다.', 409);
}
function ddayReferences(context) {
  const sources = [{sourceScope: `user:${context.uid}`, base: ['users', context.uid]}];
  if (context.pairId) sources.push({sourceScope: `pair:${context.pairId}`, base: ['pairs', context.pairId]});
  return {sources: sources.map(source => ({...source, legacyRef: doc(db, ...source.base, 'app', 'main'), storedRef: doc(db, ...source.base, 'app', 'ddays')})), settingsRef: doc(db, 'users', context.uid, 'app', 'dday-settings')};
}
function ddaySnapshotPayload(snapshot) {
  if (!snapshot.exists()) return null;
  if (snapshot.data()?.payload == null) ddayFailure('D-day 저장 문서의 내용을 확인할 수 없습니다. 원본을 변경하지 않았습니다.');
  return decodeArchive(snapshot.data().payload);
}
async function loadDdaySources(context, refs, read = getDoc) {
  const results = await Promise.all([...refs.sources.flatMap(source => [read(source.legacyRef), read(source.storedRef)]), read(refs.settingsRef)]);
  assertDdayContext(context);
  return {sources: refs.sources.map((source, index) => ({sourceScope: source.sourceScope, legacy: ddaySnapshotPayload(results[index * 2]), stored: ddaySnapshotPayload(results[index * 2 + 1])})), settings: ddaySnapshotPayload(results.at(-1))};
}
async function readDdayDataForContext(context) {
  const refs = ddayReferences(context);
  // One-time, add-only protection within the original scope. Neither app/main
  // nor another scope is changed. Existing rows and deletion markers win.
  const result = await runTransaction(db, async transaction => {
    assertDdayContext(context);
    const data = await loadDdaySources(context, refs, ref => transaction.get(ref));
    const items = mergeDdaySources(data.sources, context), active = resolveDdaySelection(items, data.settings, data.sources, context);
    for (let index = 0; index < data.sources.length; index++) {
      const source = data.sources[index], protectedData = preserveDdayRows(source.stored, items, source.sourceScope);
      if (protectedData.changed) transaction.set(refs.sources[index].storedRef, ddayDocument(protectedData.store, context));
    }
    if (data.settings == null && active) transaction.set(refs.settingsRef, ddayDocument({version:174,activeId:active.id,activeScope:active.sourceScope}, context));
    assertDdayContext(context);
    return {items, activeId: active?.id || '', activeScope: active?.sourceScope || ''};
  }, {maxAttempts:1});
  assertDdayContext(context);
  return result;
}
async function readDdayData() { return readDdayDataForContext(captureDdayContext()); }
function ddayDocument(payload, context) {
  const packed = encodeStoredPayload(payload);
  if (new TextEncoder().encode(JSON.stringify(packed)).length > 850000) ddayFailure('D-day 저장 공간이 커서 저장하지 못했습니다. 원본은 유지됩니다.');
  return {payload: packed, ...storageStampV168(), updatedAt: serverTimestamp(), updatedBy: context.uid};
}
async function mutateDday(input) {
  const context = captureDdayContext(), refs = ddayReferences(context);
  if (!input || typeof input !== 'object' || Array.isArray(input)) ddayFailure('D-day 작업을 확인해주세요.');
  const action = JSON.parse(JSON.stringify(input)), currentScope = context.pairId ? `pair:${context.pairId}` : `user:${context.uid}`;
  if (!['add', 'select', 'delete'].includes(action.type)) ddayFailure('지원하지 않는 D-day 작업입니다.');
  const sourceScope = action.sourceScope ? ddayScope(action.sourceScope) : currentScope;
  if (!refs.sources.some(source => source.sourceScope === sourceScope) || action.type === 'add' && sourceScope !== currentScope) ddayFailure('현재 사용 가능한 D-day 저장 공간이 아닙니다.', 403);
  await runTransaction(db, async transaction => {
    assertDdayContext(context);
    const data = await loadDdaySources(context, refs, ref => transaction.get(ref)), visibleItems = mergeDdaySources(data.sources, context);
    resolveDdaySelection(visibleItems, data.settings, data.sources, context);
    const target = data.sources.find(source => source.sourceScope === sourceScope);
    const result = mutateDdayStore(target.stored, action, {context, sourceScope, visibleItems});
    assertDdayContext(context);
    if (result.changed) transaction.set(refs.sources.find(source => source.sourceScope === sourceScope).storedRef, ddayDocument(result.store, context));
    const selected = data.settings || {};
    if (action.type === 'select' || action.type === 'add' && result.added) {
      if (selected.activeId !== result.id || selected.activeScope !== sourceScope) transaction.set(refs.settingsRef, ddayDocument({version:174, activeId: result.id, activeScope: sourceScope}, context));
    } else if (action.type === 'delete' && selected.activeId === result.id && selected.activeScope === sourceScope) {
      transaction.set(refs.settingsRef, ddayDocument({version:174, activeId:'', activeScope:''}, context));
    }
  }, {maxAttempts:1});
  assertDdayContext(context);
  const result = await readDdayDataForContext(context);
  assertDdayContext(context);
  window.dispatchEvent(new CustomEvent('aiderdear-dday-data', {detail:{uid:context.uid,pairId:context.pairId}}));
  return result;
}

const copyJson = value => JSON.parse(JSON.stringify(value ?? null));

// Owner originals never enter app/main. Only explicit v178 day toggles create
// a minimal projection in the currently linked couple's dedicated collection.
// Queries are bounded; a truncated range explicitly disables period estimates.
function assertPrivateCalendarContext(context) {
  if (state.user?.uid !== context.uid || auth.currentUser !== context.principal || auth.currentUser?.uid !== context.uid) privateCalendarFailure('로그인 계정이 변경되어 개인 캘린더 작업을 중단했습니다.', 'unauthenticated');
  if ((state.pair?.id || '') !== context.pairId) privateCalendarFailure('커플 연결이 변경되어 날짜 기록 작업을 중단했습니다. 다시 눌러주세요.', 'conflict');
}
async function capturePrivateCalendarContext() {
  const user = requireUser(), principal = auth.currentUser;
  const context = {uid:privateCalendarId(user.uid), principal, pairId:state.pair?.id ? privateCalendarId(state.pair.id) : '', canUseIntimacy:false};
  assertPrivateCalendarContext(context);
  const token = await principal.getIdTokenResult();
  assertPrivateCalendarContext(context);
  if (token.claims?.sub !== context.uid) privateCalendarFailure('로그인 정보를 다시 확인해주세요.', 'unauthenticated');
  context.canUseIntimacy = canUsePrivateIntimacy(principal)
    && token.claims.email_verified === true && token.claims.email === principal.email;
  return context;
}
async function privateCalendarPair(context, read=getDoc) {
  if (!context.pairId) return null;
  const [pair, membership] = await Promise.all([read(doc(db,'pairs',context.pairId)),read(doc(db,'pairMemberships',context.uid))]);
  assertPrivateCalendarContext(context);
  const value=pair.exists()?pair.data():null, own=membership.exists()?membership.data():null;
  if (!value || value.status!=='active' || !Array.isArray(value.memberUids) || value.memberUids.length!==2 || new Set(value.memberUids).size!==2 || !value.memberUids.includes(context.uid)
      || own?.status!=='active' || own.pairId!==context.pairId) privateCalendarFailure('커플 연결을 다시 확인해주세요. 기록과 입력은 유지됩니다.','permission-denied');
  return value;
}
function privateCalendarRef(context, collectionName, id) {
  return doc(db, 'users', context.uid, collectionName, id);
}
function privateCalendarSnapshot(snapshot, context) {
  if (!snapshot.exists()) return null;
  const value = snapshot.data();
  if (value.ownerUid !== context.uid || value.version !== PRIVATE_CALENDAR_VERSION) privateCalendarFailure('개인 캘린더 저장 형식을 확인할 수 없습니다. 원본은 유지됩니다.');
  return value;
}
async function readPrivateCalendarData(input) {
  try {
    const range = privateCalendarRange(input), context = await capturePrivateCalendarContext();
    const pair=await privateCalendarPair(context);
    const periodQuery = query(collection(db, 'users', context.uid, 'menstrualEntries'), where('startDate', '>=', range.historyFrom), where('startDate', '<=', range.to), orderBy('startDate', 'desc'), limit(201));
    const dateQuery=(path,from=range.from)=>getDocs(query(collection(db,...path),where('date','>=',from),where('date','<=',range.to),orderBy('date','desc'),limit(201)));
    const [settingsSnapshot, periodSnapshot, intimacySnapshot, periodDays, intimacyDays, sharedPeriods, sharedIntimacy] = await Promise.all([
      getDoc(privateCalendarRef(context, 'healthCalendar', 'settings')),getDocs(periodQuery),
      context.canUseIntimacy?dateQuery(['users',context.uid,'intimacyEntries']):null,
      dateQuery(['users',context.uid,'menstrualDays'],range.historyFrom),
      context.canUseIntimacy?dateQuery(['users',context.uid,'intimacyDays']):null,
      pair?dateQuery(['pairs',context.pairId,'menstrualDays']):null,
      pair&&context.canUseIntimacy?dateQuery(['pairs',context.pairId,'intimacyDays']):null,
    ]);
    assertPrivateCalendarContext(context);
    const unpack = (snapshot, kind) => (snapshot?.docs || []).slice(0, 200).map(row => {
      const value = privateCalendarSnapshot(row, context);
      if (!value || value.id !== row.id || value.deleted === true) privateCalendarFailure('개인 기록 형식을 확인할 수 없습니다. 원본은 유지됩니다.');
      return normalizePrivateCalendarEntry(kind, value, true);
    });
    const unpackDays=(snapshot,kind,shared=false)=>(snapshot?.docs||[]).slice(0,200).map(row=>{
      const value=shared?row.data():privateCalendarSnapshot(row,context);
      if (!value || value.kind!==kind || value.version!==PRIVATE_CALENDAR_VERSION || (shared?(!pair.memberUids.includes(value.ownerUid)||row.id!==`${value.ownerUid}_${value.date}`||value.pairId!==context.pairId):row.id!==value.date)) privateCalendarFailure('날짜 기록 형식을 확인할 수 없습니다. 원본은 유지됩니다.');
      return {...normalizePrivateCalendarDay(value,true),ownerUid:value.ownerUid};
    }).filter(row=>!shared||row.ownerUid!==context.uid);
    const truncated=snapshot=>(snapshot?.docs.length||0)>200;
    return {settings:normalizePrivateCalendarSettings(privateCalendarSnapshot(settingsSnapshot, context)), periods:unpack(periodSnapshot, 'period'), intimacy:unpack(intimacySnapshot, 'intimacy'),
      periodDays:unpackDays(periodDays,'period'),intimacyDays:unpackDays(intimacyDays,'intimacy'),sharedPeriods:unpackDays(sharedPeriods,'period',true),sharedIntimacy:unpackDays(sharedIntimacy,'intimacy',true),
      canUseIntimacy:context.canUseIntimacy, hasMore:{periods:truncated(periodSnapshot)||truncated(periodDays),intimacy:truncated(intimacySnapshot)||truncated(intimacyDays),shared:truncated(sharedPeriods)||truncated(sharedIntimacy)}};
  } catch (error) { throw privateCalendarError(error); }
}
async function mutatePrivateCalendar(input) {
  try {
    // Validate before network and preserve the caller's input through all awaits.
    const action = JSON.parse(JSON.stringify(input || {}));
    privateCalendarRevision(action.expectedRevision);
    if(action.type==='day-set')return await mutatePrivateCalendarDay(action);
    privateCalendarMutation({...action, expectedRevision:0}, null);
    const context = await capturePrivateCalendarContext(), type = action.type;
    if (type.startsWith('intimacy-') && !context.canUseIntimacy) privateCalendarFailure('이 계정에서는 관계일 기록을 사용할 수 없습니다.', 'permission-denied');
    const collectionName = type === 'settings' ? 'healthCalendar' : type.startsWith('period-') ? 'menstrualEntries' : 'intimacyEntries';
    const id = type === 'settings' ? 'settings' : privateCalendarId(action.item?.id || action.id);
    const ref = privateCalendarRef(context, collectionName, id);
    const result = await runTransaction(db, async transaction => {
      assertPrivateCalendarContext(context);
      const snapshot = await transaction.get(ref);
      assertPrivateCalendarContext(context);
      const previous = privateCalendarSnapshot(snapshot, context), result = privateCalendarMutation(action, previous);
      if (result.changed) {
        const row = result.settings || result.item || {id:result.id, revision:result.revision, deleted:true};
        transaction.set(ref, {...row, ownerUid:context.uid, version:PRIVATE_CALENDAR_VERSION, createdAt:previous?.createdAt || serverTimestamp(), updatedAt:serverTimestamp()});
      }
      return result;
    }, {maxAttempts:1});
    assertPrivateCalendarContext(context);
    window.dispatchEvent(new CustomEvent('aiderdear-private-calendar-data', {detail:{uid:context.uid}}));
    return result;
  } catch (error) { throw privateCalendarError(error); }
}

async function mutatePrivateCalendarDay(action) {
  privateCalendarDayMutation({...action,expectedRevision:0});
  const context=await capturePrivateCalendarContext();
  if(action.kind==='intimacy'&&!context.canUseIntimacy)privateCalendarFailure('이 계정에서는 관계일 기록을 사용할 수 없습니다.','permission-denied');
  const collectionName=action.kind==='period'?'menstrualDays':'intimacyDays',ref=privateCalendarRef(context,collectionName,action.date);
  const result=await runTransaction(db,async transaction=>{
    assertPrivateCalendarContext(context);
    const pair=await privateCalendarPair(context,ref=>transaction.get(ref));
    const settingsRef=privateCalendarRef(context,'healthCalendar','settings');
    const [snapshot,settingsSnapshot]=await Promise.all([transaction.get(ref),action.kind==='period'&&action.active?transaction.get(settingsRef):null]);
    assertPrivateCalendarContext(context);
    const previous=privateCalendarSnapshot(snapshot,context),result=privateCalendarDayMutation(action,previous);
    // Replaying a completed request is a no-op, never a historical share/backfill.
    if(!result.changed)return result;
    const stamp={ownerUid:context.uid,version:PRIVATE_CALENDAR_VERSION,createdAt:previous?.createdAt||serverTimestamp(),updatedAt:serverTimestamp()};
    transaction.set(ref,{...result.item,...stamp});
    if(settingsSnapshot){const stored=privateCalendarSnapshot(settingsSnapshot,context),settings=normalizePrivateCalendarSettings(stored);if(!settings.menstrualEnabled)transaction.set(settingsRef,{...settings,menstrualEnabled:true,revision:settings.revision+1,ownerUid:context.uid,version:PRIVATE_CALENDAR_VERSION,createdAt:stored?.createdAt||serverTimestamp(),updatedAt:serverTimestamp()});}
    if(pair)transaction.set(doc(db,'pairs',context.pairId,collectionName,`${context.uid}_${action.date}`),{...result.item,ownerUid:context.uid,pairId:context.pairId,version:PRIVATE_CALENDAR_VERSION,updatedAt:serverTimestamp()});
    return result;
  },{maxAttempts:1});
  assertPrivateCalendarContext(context);
  window.dispatchEvent(new CustomEvent('aiderdear-private-calendar-data',{detail:{uid:context.uid}}));
  return result;
}

function watchPrivateCalendarPair(input,changed,failed) {
  let cancelled=false;const subscriptions=[];
  Promise.resolve().then(async()=>{
    const range=privateCalendarRange(input),context=await capturePrivateCalendarContext();
    const pair=await privateCalendarPair(context);if(cancelled||!pair)return;
    for(const name of ['menstrualDays',...(context.canUseIntimacy?['intimacyDays']:[])]){
      const ref=query(collection(db,'pairs',context.pairId,name),where('date','>=',range.from),where('date','<=',range.to),orderBy('date','desc'),limit(201));
      subscriptions.push(onSnapshot(ref,()=>{if(cancelled)return;try{assertPrivateCalendarContext(context);changed?.();}catch(error){failed?.(privateCalendarError(error));}},error=>{if(!cancelled)failed?.(privateCalendarError(error));}));
    }
  }).catch(error=>{if(!cancelled)failed?.(privateCalendarError(error));});
  return()=>{cancelled=true;subscriptions.splice(0).forEach(stop=>stop());};
}

function eventPairKey() {
  const emails = (Array.isArray(state.pair?.memberEmails) ? state.pair.memberEmails : [])
    .map(cleanEmail)
    .filter(Boolean)
    .sort();
  return emails.join('::');
}

function mergeEventRows(currentRows, soloRows, ownerField, pairKey) {
  const rows = new Map();
  const add = (row, fromSolo = false) => {
    if (!row?.id) return;
    const next = copyJson(row);
    if (fromSolo) {
      next[ownerField] = cleanEmail(next[ownerField] || state.user?.email);
      next.pairKey = pairKey;
    }
    const previous = rows.get(String(next.id));
    const previousTime = Number(previous?.updatedAt || previous?.createdAt || 0);
    const nextTime = Number(next.updatedAt || next.createdAt || 0);
    if (!previous || nextTime >= previousTime) rows.set(String(next.id), next);
  };
  (Array.isArray(currentRows) ? currentRows : []).forEach(row => add(row));
  (Array.isArray(soloRows) ? soloRows : []).forEach(row => add(row, true));
  return [...rows.values()];
}

function mergeEventFolders(currentFolders, soloFolders) {
  const folders = new Map();
  [...(Array.isArray(currentFolders) ? currentFolders : []), ...(Array.isArray(soloFolders) ? soloFolders : [])]
    .forEach(folder => {
      if (!folder?.id) return;
      const previous = folders.get(String(folder.id));
      if (!previous || Number(folder.createdAt || 0) >= Number(previous.createdAt || 0)) {
        folders.set(String(folder.id), copyJson(folder));
      }
    });
  return [...folders.values()];
}

function mergeSoloEventPayload(sharedPayload, soloPayload) {
  const shared = copyJson(sharedPayload || {}) || {};
  const solo = copyJson(soloPayload || {}) || {};
  const pairKey = eventPairKey();
  const soloKey = `solo:${cleanEmail(state.user?.email)}`;
  shared.records = mergeEventRows(shared.records, solo.records, 'authorEmail', pairKey);
  shared.eventReviews = mergeEventRows(shared.eventReviews, solo.eventReviews, 'authorEmail', pairKey);
  shared.bucketItems = mergeEventRows(shared.bucketItems, solo.bucketItems, 'createdBy', pairKey);
  shared.albumsBySpace = shared.albumsBySpace && typeof shared.albumsBySpace === 'object' ? shared.albumsBySpace : {};
  shared.travelFoldersBySpace = shared.travelFoldersBySpace && typeof shared.travelFoldersBySpace === 'object' ? shared.travelFoldersBySpace : {};
  const soloAlbums = solo.albumsBySpace?.[soloKey] || (Array.isArray(solo.albums) ? solo.albums : []);
  const soloTrips = solo.travelFoldersBySpace?.[soloKey] || [];
  shared.albumsBySpace[pairKey] = mergeEventFolders(shared.albumsBySpace[pairKey], soloAlbums);
  shared.travelFoldersBySpace[pairKey] = mergeEventFolders(shared.travelFoldersBySpace[pairKey], soloTrips);
  shared.eventMigrationByUid = shared.eventMigrationByUid && typeof shared.eventMigrationByUid === 'object' ? shared.eventMigrationByUid : {};
  shared.eventMigrationByUid[state.user.uid] = Date.now();
  return shared;
}

function eventMediaIds(payload) {
  const ids = new Set();
  (Array.isArray(payload?.records) ? payload.records : []).forEach(row => {
    (Array.isArray(row?.media) ? row.media : []).forEach(item => {
      const id = String(item?.fileId || item?.key || '');
      if (id) ids.add(id);
    });
  });
  (Array.isArray(payload?.eventReviews) ? payload.eventReviews : []).forEach(row => {
    const id = String(row?.media?.fileId || '');
    if (id) ids.add(id);
  });
  (Array.isArray(payload?.bucketItems) ? payload.bucketItems : []).forEach(row => {
    const id = String(row?.photo?.fileId || '');
    if (id) ids.add(id);
  });
  return [...ids];
}

async function copyOwnEventMediaToPair(mediaId) {
  const user = requireUser();
  if (!state.pair || !mediaId) return;
  const sourceRef = doc(db, 'users', user.uid, 'media', mediaId);
  const targetRef = doc(db, 'pairs', state.pair.id, 'media', mediaId);
  if ((await getDoc(targetRef)).exists()) return;
  const sourceSnapshot = await getDoc(sourceRef);
  if (!sourceSnapshot.exists()) return;
  const chunks = await getDocs(collection(sourceRef, 'chunks'));
  for (let start = 0; start < chunks.docs.length; start += 400) {
    const batch = writeBatch(db);
    chunks.docs.slice(start, start + 400).forEach(item => {
      batch.set(doc(targetRef, 'chunks', item.id), item.data());
    });
    await batch.commit();
  }
  await setDoc(targetRef, {
    ...sourceSnapshot.data(),
    migratedFromUid: user.uid,
    migratedAt: serverTimestamp(),
  });
}

async function migrateEventWorkspace() {
  const user = requireUser();
  if (!state.pair) return readAppData();
  const soloRef = doc(db, 'users', user.uid, 'app', 'main');
  const pairRef = doc(db, 'pairs', state.pair.id, 'app', 'main');
  const [soloSnapshot, pairSnapshot] = await Promise.all([getDoc(soloRef), getDoc(pairRef)]);
  const soloPayload = soloSnapshot.exists() ? decodeArchive(soloSnapshot.data().payload) || {} : {};
  let pairPayload = pairSnapshot.exists() ? decodeArchive(pairSnapshot.data().payload) || {} : {};
  if (!pairPayload.eventMigrationByUid?.[user.uid]) {
    pairPayload = await runTransaction(db, async transaction => {
      const currentPairSnapshot = await transaction.get(pairRef);
      const currentPairPayload = currentPairSnapshot.exists() ? decodeArchive(currentPairSnapshot.data().payload) || {} : {};
      if (currentPairPayload.eventMigrationByUid?.[user.uid]) return currentPairPayload;
      const merged = mergeSoloEventPayload(currentPairPayload, soloPayload);
      transaction.set(pairRef, {
        payload: encodeStoredPayload(merged), ...storageStampV168(),
        updatedAt: serverTimestamp(),
        updatedBy: user.uid,
      });
      return merged;
    });
  }
  if (!pairPayload.eventMediaMigrationByUid?.[user.uid]) {
    let complete = true;
    for (const mediaId of eventMediaIds(soloPayload)) {
      try { await copyOwnEventMediaToPair(mediaId); }
      catch (error) { complete = false; console.warn('EVENT media migration skipped', mediaId, error); }
    }
    if (complete) {
      pairPayload = await runTransaction(db, async transaction => {
        const currentPairSnapshot = await transaction.get(pairRef);
        const current = currentPairSnapshot.exists() ? decodeArchive(currentPairSnapshot.data().payload) || {} : {};
        current.eventMediaMigrationByUid = current.eventMediaMigrationByUid && typeof current.eventMediaMigrationByUid === 'object' ? current.eventMediaMigrationByUid : {};
        current.eventMediaMigrationByUid[user.uid] = Date.now();
        transaction.set(pairRef, { payload: encodeStoredPayload(current), ...storageStampV168(), updatedAt: serverTimestamp(), updatedBy: user.uid });
        return current;
      });
    }
  }
  return pairPayload;
}

async function writeAppData(payload) {
  const user = requireUser();
  await setDoc(scopedDoc('app'), {
    payload: encodeStoredPayload(JSON.parse(JSON.stringify(payload))), ...storageStampV168(),
    updatedAt: serverTimestamp(),
    updatedBy: user.uid,
  });
}

function ownScheduleRef() {
  const user = requireUser();
  return doc(db, 'users', user.uid, 'schedule', 'main');
}

function pairScheduleRef(uid) {
  requireUser();
  if (!state.pair) return null;
  return doc(db, 'pairs', state.pair.id, 'schedules', String(uid));
}

function cleanScheduleRows(rows, ownerUid = '') {
  const user = requireUser();
  const email = cleanEmail(user.email);
  return (Array.isArray(rows) ? rows : [])
    .filter(row => row && row.id && row.authorEmail && cleanEmail(row.authorEmail) === email)
    .map(row => ({
      ...JSON.parse(JSON.stringify(row)),
      authorEmail: email,
      authorUid: String(ownerUid || user.uid),
      owner: row.owner === 'shared' || row.shareWithCouple ? 'shared' : 'mine',
      shareWithCouple: !!row.shareWithCouple || row.owner === 'shared',
      pairKey: (row.owner === 'shared' || row.shareWithCouple) && state.pair ? state.pair.id : '',
    }))
    ;
}

async function readScheduleData() {
  const user = requireUser();
  const ownSnapshot = await getDoc(ownScheduleRef());
  const own = ownSnapshot.exists() ? decodeArchive(ownSnapshot.data().payload) || [] : [];
  let shared = [];
  if (state.pair && state.partner?.uid) {
    const partnerSnapshot = await getDoc(pairScheduleRef(state.partner.uid));
    shared = partnerSnapshot.exists() ? decodeArchive(partnerSnapshot.data().payload) || [] : [];
  }
  return {
    own: Array.isArray(own) ? own : [],
    shared: Array.isArray(shared) ? shared : [],
  };
}

async function writeScheduleData(rows) {
  const user = requireUser();
  const own = cleanScheduleRows(rows, user.uid);
  const writes = [setDoc(ownScheduleRef(), {
    payload: encodeStoredPayload(own), ...storageStampV168(),
    updatedAt: serverTimestamp(),
    updatedBy: user.uid,
  })];
  const pairRef = pairScheduleRef(user.uid);
  if (pairRef) {
    const shared = own.filter(row => row.owner === 'shared' || row.shareWithCouple);
    writes.push(setDoc(pairRef, {
      payload: encodeStoredPayload(shared), ...storageStampV168(),
      ownerUid: user.uid,
      ownerEmail: user.email,
      updatedAt: serverTimestamp(),
    }));
  }
  await Promise.all(writes);
}

function watchScheduleData(callback) {
  const user = requireUser();
  try { unsubscribeOwnSchedule?.(); } catch {}
  try { unsubscribePartnerSchedule?.(); } catch {}
  let own = [];
  let shared = [];
  let ownReady = false;
  let sharedReady = !state.pair || !state.partner?.uid;
  const emitRows = () => {
    if (ownReady && sharedReady) callback({ own: [...own], shared: [...shared] });
  };
  unsubscribeOwnSchedule = onSnapshot(
    ownScheduleRef(),
    snapshot => {
      own = snapshot.exists() ? decodeArchive(snapshot.data().payload) || [] : [];
      ownReady = true;
      emitRows();
    },
    error => console.warn('Private schedule listener stopped', error),
  );
  if (state.pair && state.partner?.uid) {
    unsubscribePartnerSchedule = onSnapshot(
      pairScheduleRef(state.partner.uid),
      snapshot => {
        shared = snapshot.exists() ? decodeArchive(snapshot.data().payload) || [] : [];
        sharedReady = true;
        emitRows();
      },
      error => console.warn('Shared schedule listener stopped', error),
    );
  } else {
    unsubscribePartnerSchedule = null;
    emitRows();
  }
  return () => {
    try { unsubscribeOwnSchedule?.(); } catch {}
    try { unsubscribePartnerSchedule?.(); } catch {}
    unsubscribeOwnSchedule = unsubscribePartnerSchedule = null;
  };
}

async function getFirebaseIdToken(forceRefresh = false) {
  requireUser();
  return auth.currentUser.getIdToken(Boolean(forceRefresh));
}

async function readPrivateData() {
  const user = requireUser();
  const snapshot = await getDoc(doc(db, 'users', user.uid, 'private', 'main'));
  return consultSyncV167.remember(user.uid, snapshot.exists() ? decodeArchive(snapshot.data().payload) || null : null);
}

const consultSyncV167 = createConsultSync({
  currentUid:()=>auth.currentUser?.uid,
  readCurrent:async uid=>decodeArchive((await getDoc(doc(db,'users',uid,'private','main'))).data()?.payload)||{},
  commitRecord:async(uid,input)=>{
    if(auth.currentUser?.uid!==uid)throw Error('계정이 변경되었습니다.');
    const token=await auth.currentUser.getIdToken();
    if(auth.currentUser?.uid!==uid)throw Error('계정이 변경되었습니다.');
    const response=await fetch('/api/consult',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(input)});
    const result=await response.json();
    if(!response.ok)throw Object.assign(Error(result.error||'컨설트 저장에 실패했습니다.'),{status:response.status});
    return result;
  },
  writeRemaining:async(uid,incoming)=>{
    const ref=doc(db,'users',uid,'private','main');
    return runTransaction(db,async transaction=>{
      const snap=await transaction.get(ref),rawCurrent=snap.data()?.payload||{},current=decodeArchive(rawCurrent),next=JSON.parse(JSON.stringify(incoming));
      if(auth.currentUser?.uid!==uid)throw Error('계정이 변경되었습니다.');
      for(const key of CONSULT_KEYS){if(Object.hasOwn(current,key))next[key]=current[key];else delete next[key];}
      if(snap.exists()){
        const fields=[new FieldPath('updatedAt'),serverTimestamp(),new FieldPath('storageVersion'),168,new FieldPath('formatWrittenAt'),serverTimestamp()];
        for(const [key,value] of Object.entries(incoming))if(!CONSULT_KEYS.includes(key))fields.push(new FieldPath('payload',key),encodeArchive(value));
        for(const key of Object.keys(current))if(!CONSULT_KEYS.includes(key)&&!Object.prototype.hasOwnProperty.call(incoming,key))fields.push(new FieldPath('payload',key),deleteField());
        transaction.update(ref,...fields);
      }else transaction.set(ref,{payload:encodeStoredPayload(next),...storageStampV168(),updatedAt:serverTimestamp()});
      return next;
    });
  }
});

// BEGIN WIDGET ACTION TRANSACTION V165
// A widget changes one explicit record, never the caller's cached private document.
// Receipts live beside main, so legacy full-document saves cannot erase replay keys.
async function applyWidgetActionV165(input = {}) {
  const fail = (code, message) => { const error = new Error(message); error.code = code; throw error; };
  const uid = String(input.uid || '');
  const assertOwner = () => {
    if (!uid || auth.currentUser?.uid !== uid || state.user?.uid !== uid) {
      fail('widget/owner-changed', '계정이 변경되었습니다. 앱에서 다시 동기화해주세요.');
    }
  };
  assertOwner();
  const op = String(input.op || ''), id = String(input.id || ''), key = String(input.key || '');
  if (!['todo', 'routine', 'add-memo', 'add-todo'].includes(op) || !id || id.length > 180 || !key) {
    fail('widget/invalid-action', '위젯 작업 정보가 올바르지 않습니다.');
  }
  const keyBytes = new TextEncoder().encode(key);
  if (keyBytes.length > 600) fail('widget/invalid-action', '위젯 작업 키가 너무 깁니다.');
  const adding = op === 'add-memo' || op === 'add-todo';
  const expected = Number(input.expectedUpdatedAt);
  if (!adding && (input.expectedUpdatedAt == null || !Number.isFinite(expected) || expected < 0)) {
    fail('widget/stale-action', '이 기록을 다시 불러온 후 변경해주세요.');
  }
  const date = String(input.date || '');
  const validDate = value => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const parsed = new Date(value + 'T12:00:00Z');
    return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
  };
  let value;
  if (op === 'todo') {
    if (![true, false, 'true', 'false'].includes(input.value)) fail('widget/invalid-action', '완료 상태가 올바르지 않습니다.');
    value = input.value === true || input.value === 'true';
  } else if (op === 'routine') {
    value = String(input.value || '').toUpperCase();
    if (!['MINI', 'MORE', 'MAX', 'SKIP', ''].includes(value) || !validDate(date)) {
      fail('widget/invalid-action', '루틴 날짜 또는 단계가 올바르지 않습니다.');
    }
    const current = new Date();
    const today = current.getFullYear() + '-' + String(current.getMonth() + 1).padStart(2, '0') + '-' + String(current.getDate()).padStart(2, '0');
    if (date > today) fail('widget/invalid-action', '미래 날짜에는 루틴을 기록할 수 없습니다.');
  } else {
    value = typeof input.value === 'string' ? input.value.trim() : '';
    if (!value || value.length > 180 || (op === 'add-todo' && date && !validDate(date))) {
      fail('widget/invalid-action', '내용은 180자 이내로 입력하고 마감일을 확인해주세요.');
    }
  }
  const fingerprint = JSON.stringify([op, id, op === 'add-memo' ? '' : date, value, adding ? null : expected]);
  const receiptId = 'widget-action-v165-' + Array.from(keyBytes, byte => byte.toString(16).padStart(2, '0')).join('');
  const mainRef = doc(db, 'users', uid, 'private', 'main');
  const receiptRef = doc(db, 'users', uid, 'private', receiptId);
  const result = await runTransaction(db, async transaction => {
    // Firestore can retry this callback: no local state changes or network side effects.
    assertOwner();
    const [main, receipt] = await Promise.all([transaction.get(mainRef), transaction.get(receiptRef)]);
    assertOwner();
    const stored = main.exists() ? decodeArchive(main.data().payload) : null;
    if (stored != null && (typeof stored !== 'object' || Array.isArray(stored))) {
      fail('widget/invalid-data', '기존 기록 형식을 확인해주세요. 위젯에서는 덮어쓰지 않았습니다.');
    }
    const payload = stored || {};
    if (receipt.exists()) {
      const previous = receipt.data();
      if (previous.uid !== uid || previous.key !== key || previous.fingerprint !== fingerprint) {
        fail('widget/replay-mismatch', '이 작업 키가 다른 변경에 사용되었습니다. 다시 불러와주세요.');
      }
      return {applied: false, replayed: true, payload};
    }
    const collectionKey = op === 'routine' ? 'routines' : 'checklists';
    if (payload[collectionKey] != null && !Array.isArray(payload[collectionKey])) {
      fail('widget/invalid-data', '기존 기록 형식을 확인해주세요. 위젯에서는 덮어쓰지 않았습니다.');
    }
    const rows = payload[collectionKey] || [];
    const index = rows.findIndex(row => row && String(row.id) === id);
    let nextRow, changed = true;
    if (adding) {
      if (index !== -1) fail('widget/stale-action', '같은 ID의 기록이 이미 있습니다. 다시 불러와주세요.');
      const stamp = Date.now();
      nextRow = {id, text: value, date: op === 'add-todo' ? date : '', kind: op === 'add-memo' ? 'memo' : 'todo', done: false, createdAt: stamp, updatedAt: stamp};
    } else {
      if (index < 0) fail('widget/not-found', '기록이 삭제되었거나 변경되었습니다. 다시 불러와주세요.');
      const row = rows[index];
      const revision = Number(row.updatedAt || row.createdAt || 0);
      if (!Number.isFinite(revision) || revision !== expected) {
        fail('widget/stale-action', '다른 곳에서 수정된 기록입니다. 최신 내용을 다시 불러와주세요.');
      }
      const stamp = Math.max(Date.now(), revision + 1);
      if (op === 'todo') {
        if (row.kind === 'memo' || row.type === 'memo') fail('widget/invalid-action', '메모에는 완료 상태를 설정할 수 없습니다.');
        changed = Boolean(row.done) !== value;
        nextRow = {...row, done: value, completedAt: value ? stamp : 0, updatedAt: stamp};
      } else {
        if ((row.doneDates != null && !Array.isArray(row.doneDates)) || (row.dailyLevels != null && (typeof row.dailyLevels !== 'object' || Array.isArray(row.dailyLevels)))) {
          fail('widget/invalid-data', '기존 루틴 기록 형식을 확인해주세요.');
        }
        if (Object.keys(row.goalDerivedDates||{}).length || Object.values(row.goalTracking||{}).some(days=>Object.keys(days||{}).length)) fail('widget/goal-linked','목표와 연결된 루틴입니다. 앱에서 목표별 수행을 수정해주세요.');
        const oldDates = row.doneDates || [], oldLevels = row.dailyLevels || {};
        const doneDates = oldDates.filter(day => day !== date), dailyLevels = {...oldLevels};
        if (value && value !== 'SKIP') {
          // Keep legacy lower-case storage compatible; current app records use upper-case.
          const sample = String(oldLevels[date] || Object.values(oldLevels).find(level => /^(mini|more|max)$/i.test(String(level))) || '');
          dailyLevels[date] = sample && sample === sample.toLowerCase() ? value.toLowerCase() : value;
          if (oldDates.includes(date)) doneDates.splice(Math.min(oldDates.indexOf(date), doneDates.length), 0, date);
          else doneDates.push(date);
        } else if(value==='SKIP') dailyLevels[date]='SKIP'; else delete dailyLevels[date];
        changed = JSON.stringify(doneDates) !== JSON.stringify(oldDates) || JSON.stringify(dailyLevels) !== JSON.stringify(oldLevels);
        nextRow = {...row, doneDates, dailyLevels, updatedAt: stamp};
      }
    }
    let nextPayload = payload;
    if (changed) {
      const nextRows = rows.slice();
      if (adding) nextRows.push(nextRow); else nextRows[index] = nextRow;
      nextPayload = {...payload, [collectionKey]: nextRows};
      assertOwner();
      if (main.exists()) transaction.update(mainRef, new FieldPath('payload',collectionKey),encodeArchive(nextRows),new FieldPath('updatedAt'),serverTimestamp(),new FieldPath('storageVersion'),168,new FieldPath('formatWrittenAt'),serverTimestamp());
      else transaction.set(mainRef, {payload: encodeStoredPayload(nextPayload), ...storageStampV168(), updatedAt: serverTimestamp()});
    }
    assertOwner();
    transaction.set(receiptRef, {schema: 165, uid, key, fingerprint, applied: changed, createdAt: serverTimestamp()});
    return {applied: changed, replayed: false, payload: nextPayload};
  });
  // A response received after account switching must never populate the next account.
  assertOwner();
  return result;
}
// END WIDGET ACTION TRANSACTION V165

async function writePrivateData(payload) {
  requireUser();
  return consultSyncV167.write(payload);
}

async function readPaperTaskData() {
  const snapshot = await getDoc(paperTaskWorkspaceRef());
  return snapshot.exists() ? decodeArchive(snapshot.data().payload) || null : null;
}

async function writePaperTaskData(payload) {
  const user = requirePaperTaskMember();
  await setDoc(paperTaskWorkspaceRef(), {
    payload: encodeStoredPayload(JSON.parse(JSON.stringify(payload || {}))), ...storageStampV168(),
    updatedAt: serverTimestamp(),
    updatedBy: user.uid,
    updatedByEmail: user.email,
  });
}

function watchPaperTaskData(callback) {
  paperTaskWorkspaceRef();
  return onSnapshot(
    doc(db, 'sharedWorkspaces', PAPER_TASK_WORKSPACE_ID),
    snapshot => callback(snapshot.exists() ? decodeArchive(snapshot.data().payload) || null : null),
    error => console.warn('PAPER · TASK workspace listener stopped', error),
  );
}

async function readPaperAnalysis(paperId) {
  const snapshot = await getDoc(paperAnalysisRef(paperId));
  if (!snapshot.exists()) return null;
  const row = snapshot.data() || {};
  return decodeArchive(row.payload) || null;
}

async function writePaperAnalysis(paperId, payload) {
  const user = requirePaperTaskMember();
  const cleanPayload = JSON.parse(JSON.stringify(payload || {}));
  const bytes = new TextEncoder().encode(JSON.stringify(cleanPayload)).byteLength;
  if (bytes > 850000) throw new Error('분석 결과가 너무 큽니다. 표·그림 원본 파일은 제외하고 JSON 설명만 저장해주세요.');
  await setDoc(paperAnalysisRef(paperId), {
    paperId: String(paperId),
    schema: String(cleanPayload.schema || ''),
    payload: encodeStoredPayload(cleanPayload), ...storageStampV168(),
    byteSize: bytes,
    updatedAt: serverTimestamp(),
    updatedBy: user.uid,
    updatedByEmail: user.email,
  });
  return { paperId: String(paperId), byteSize: bytes };
}

async function deletePaperAnalysis(paperId) {
  requirePaperTaskMember();
  await deleteDoc(paperAnalysisRef(paperId));
}

function emotionRef(uid) {
  const user = requireUser();
  if (state.pair) return doc(db, 'pairs', state.pair.id, 'emotions', uid);
  if (uid !== user.uid) throw new Error('개인 모드에서는 본인의 감정 기록만 볼 수 있습니다.');
  return doc(db, 'users', user.uid, 'emotion', 'main');
}

async function readEmotionData(uid) {
  const snapshot = await getDoc(emotionRef(uid));
  return snapshot.exists() ? decodeArchive(snapshot.data().payload) || null : null;
}

async function writeEmotionData(payload) {
  const user = requireUser();
  const safePayload = encodeStoredPayload(JSON.parse(JSON.stringify(payload)));
  const ownSoloRef = doc(db, 'users', user.uid, 'emotion', 'main');
  const ownPairRef = emotionRef(user.uid);
  const writes = [setDoc(ownSoloRef, { payload: safePayload, ...storageStampV168(), updatedAt: serverTimestamp() })];
  if (ownPairRef.path !== ownSoloRef.path) {
    writes.push(setDoc(ownPairRef, { payload: encodeStoredPayload(withoutPrivateEmotionFlags(payload)), ...storageStampV168(), updatedAt: serverTimestamp() }));
  }
  await Promise.all(writes);
}

function mediaCollection() {
  const scope = pairScope();
  return collection(db, ...scope.base, 'media');
}

function mediaRef(mediaId) {
  const scope = pairScope();
  return doc(db, ...scope.base, 'media', mediaId);
}

async function compressImage(file) {
  if (!String(file.type || '').startsWith('image/') || file.type === 'image/gif') return file;
  // Photo batches already decode/resize once. Avoid a second WebView codec pass.
  if (file.type === 'image/jpeg' && file.size <= 500000) return file;
  let bitmap, sourceUrl='';
  try { if (typeof createImageBitmap !== 'function') throw Error('bitmap unavailable'); bitmap = await createImageBitmap(file); }
  catch {
    sourceUrl = URL.createObjectURL(file);
    try { bitmap = await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(new Error('이 사진 형식을 읽을 수 없습니다. 앨범에서 JPG 또는 PNG로 저장한 뒤 다시 선택해주세요.'));image.src=sourceUrl;}); }
    catch(error) { URL.revokeObjectURL(sourceUrl); throw error; }
  }
  const maxSide = 1600;
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  canvas.getContext('2d', { alpha: false }).drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();
  if (sourceUrl) URL.revokeObjectURL(sourceUrl);
  const blob = await new Promise((resolve, reject) => canvas.toBlob(
    value => value ? resolve(value) : reject(new Error('사진을 변환하지 못했습니다.')),
    'image/jpeg',
    0.82,
  ));
  return new File([blob], file.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg' });
}

async function videoDurationSeconds(file) {
  if (!String(file?.type || '').startsWith('video/')) return 0;
  const url = URL.createObjectURL(file);
  try {
    return await new Promise((resolve, reject) => {
      const video = document.createElement('video');
      const timer = setTimeout(() => reject(new Error('영상 재생 시간을 확인하지 못했습니다.')), 15000);
      video.preload = 'metadata';
      video.onloadedmetadata = () => { clearTimeout(timer); resolve(Number(video.duration) || 0); };
      video.onerror = () => { clearTimeout(timer); reject(new Error('영상 정보를 읽지 못했습니다.')); };
      video.src = url;
    });
  } finally {
    URL.revokeObjectURL(url);
  }
}

// An upload must never retarget another account/pair after compression awaits.
function captureMediaUploadContextV176(privateOnly = false) {
  const user = requireUser(), principal = auth.currentUser, uid = user.uid;
  if (!uid || principal?.uid !== uid) throw Object.assign(new Error('계정 상태가 변경되었습니다. 다시 로그인해주세요.'), { code: 'auth/context-changed' });
  const base = privateOnly ? ['users', uid, 'privateMedia'] : [...pairScope().base, 'media'];
  const scopeKey = JSON.stringify(base);
  return { uid, base, assertCurrent() {
    const sameUser = auth.currentUser === principal && auth.currentUser?.uid === uid && state.user?.uid === uid;
    const sameScope = sameUser && (privateOnly || JSON.stringify([...pairScope().base, 'media']) === scopeKey);
    if (!sameScope) throw Object.assign(new Error('계정 또는 공유 공간이 변경되었습니다. 원래 계정에서 기록창을 다시 열어주세요.'), { code: 'auth/context-changed' });
  } };
}

async function writeMediaChunksV178(context, ref, bytes, metadata) {
  // 8 x 700 KiB stays well below Firestore's 10 MiB request limit, including
  // document names and metadata. The final bytes and metadata commit together.
  const chunkSize = 700 * 1024, perBatch = 8;
  const chunks = collection(ref, 'chunks'), acknowledged = [];
  let metadataAttempted = false, metadataSaved = false;
  try {
    for (let start = 0; start < Math.max(1, metadata.chunkCount); start += perBatch) {
      const batch = writeBatch(db), refs = [];
      const end = Math.min(metadata.chunkCount, start + perBatch);
      for (let index = start; index < end; index += 1) {
        const target = doc(chunks, String(index).padStart(5, '0'));
        batch.set(target, { data: Bytes.fromUint8Array(bytes.slice(index * chunkSize, (index + 1) * chunkSize)) });
        refs.push(target);
      }
      const final = end === metadata.chunkCount;
      if (final) batch.set(ref, metadata);
      context.assertCurrent();
      metadataAttempted = final;
      await batch.commit();
      if (final) metadataSaved = true;
      else acknowledged.push(...refs);
      context.assertCurrent();
    }
  } catch (error) {
    // A rejected final network response can still represent a successful commit.
    // Never delete that file, nor retarget cleanup after an account/pair change.
    const code = String(error?.code || '').replace(/^firestore\//, '');
    const rejected = ['permission-denied', 'unauthenticated', 'invalid-argument',
      'failed-precondition', 'resource-exhausted', 'out-of-range', 'unimplemented'].includes(code);
    if (!metadataSaved && (!metadataAttempted || rejected) && acknowledged.length) {
      try {
        context.assertCurrent();
        const cleanup = writeBatch(db);
        acknowledged.forEach(target => cleanup.delete(target));
        await cleanup.commit();
      } catch { /* Preserve the original upload error; cleanup is best effort. */ }
    }
    throw error;
  }
}

async function uploadMedia(originalFile, label = 'media') {
  const context = captureMediaUploadContextV176();
  const file = await compressImage(originalFile);
  context.assertCurrent();
  const isVideo = String(file.type || '').startsWith('video/');
  if (isVideo) {
    const duration = await videoDurationSeconds(file);
    context.assertCurrent();
    if (duration > 310) throw new Error('영상은 5분 이내로 선택해주세요.');
    if (file.size > 120 * 1024 * 1024) throw new Error('5분 영상은 120MB 이하로 선택해주세요. 화질을 낮추면 더 오래 보관할 수 있습니다.');
  } else if (file.size > 25 * 1024 * 1024) {
    throw new Error('무료 저장공간 보호를 위해 사진은 25MB 이하만 올릴 수 있습니다.');
  }
  const mediaId = `m-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const ref = doc(db, ...context.base, mediaId);
  const bytes = new Uint8Array(await file.arrayBuffer());
  context.assertCurrent();
  const chunkSize = 700 * 1024;
  const chunkCount = Math.ceil(bytes.length / chunkSize);
  await writeMediaChunksV178(context, ref, bytes, {
    name: file.name,
    type: file.type || 'application/octet-stream',
    size: file.size,
    chunkCount,
    label,
    createdAt: serverTimestamp(),
    createdBy: context.uid,
  });
  context.assertCurrent();
  return { id: mediaId, name: file.name, mimeType: file.type, size: file.size };
}

async function readMedia(mediaId) {
  requireUser();
  const ref = mediaRef(mediaId);
  const metaSnapshot = await getDoc(ref);
  if (!metaSnapshot.exists()) throw new Error('미디어 파일을 찾을 수 없습니다.');
  const meta = metaSnapshot.data();
  const chunkSnapshot = await getDocs(collection(ref, 'chunks'));
  const parts = chunkSnapshot.docs.sort((a, b) => a.id.localeCompare(b.id)).map(item => item.data().data.toUint8Array());
  return new Blob(parts, { type: meta.type || 'application/octet-stream' });
}

async function deleteMedia(mediaId) {
  if (!mediaId) return;
  requireUser();
  const ref = mediaRef(mediaId);
  const chunkSnapshot = await getDocs(query(collection(ref, 'chunks'), limit(500)));
  const batch = writeBatch(db);
  chunkSnapshot.docs.forEach(item => batch.delete(item.ref));
  batch.delete(ref);
  await batch.commit();
}

function sharedAlbumMediaId(ownerUid, sourceId) {
  return `${ownerUid}-${String(sourceId || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 90)}`;
}

async function copyMediaToSharedAlbum(sourceId, memberUids) {
  const user = requireUser();
  const sourceRef = mediaRef(sourceId);
  const source = await getDoc(sourceRef);
  if (!source.exists()) return '';
  const targetId = sharedAlbumMediaId(user.uid, sourceId);
  const targetRef = doc(db, 'sharedAlbumMedia', targetId);
  const existing = await getDoc(targetRef);
  if (!existing.exists()) {
    await setDoc(targetRef, {
      ...source.data(), ownerUid: user.uid, sourceId: String(sourceId), memberUids, ready: false, updatedAt: serverTimestamp(),
    });
    const chunks = await getDocs(collection(sourceRef, 'chunks'));
    for (let start = 0; start < chunks.docs.length; start += 400) {
      const batch = writeBatch(db);
      chunks.docs.slice(start, start + 400).forEach(item => batch.set(doc(targetRef, 'chunks', item.id), item.data()));
      await batch.commit();
    }
  }
  await setDoc(targetRef, { memberUids, ready: true, updatedAt: serverTimestamp() }, { merge: true });
  return targetId;
}

async function deleteSharedAlbumMedia(ref) {
  const chunks = await getDocs(query(collection(ref, 'chunks'), limit(500)));
  for (let start = 0; start < chunks.docs.length; start += 400) {
    const batch = writeBatch(db);
    chunks.docs.slice(start, start + 400).forEach(item => batch.delete(item.ref));
    await batch.commit();
  }
  await deleteDoc(ref);
}

async function pruneSharedAlbumMedia(ownerUid, keepIds) {
  const snapshot = await getDocs(query(collection(db, 'sharedAlbumMedia'), where('ownerUid', '==', ownerUid), limit(300)));
  const stale = snapshot.docs.filter(item => !keepIds.has(item.id));
  await Promise.allSettled(stale.map(item => deleteSharedAlbumMedia(item.ref)));
  return stale.length;
}

async function publishSharedAlbums(payload = {}) {
  const user = requireUser();
  const allowedViewerUids = connectedRecipientUids();
  const albums = (Array.isArray(payload.albums) ? payload.albums : []).filter(row => row?.id && row?.sharedWithFriends).slice(0, 40).map(row => {
    const requested = Array.isArray(row.sharedFriendUids) && row.sharedFriendUids.length ? row.sharedFriendUids : [...allowedViewerUids];
    const viewerUids = [...new Set(requested.map(String).filter(uid => allowedViewerUids.has(uid)))].slice(0, 30);
    return { id: String(row.id), name: String(row.name || '앨범').slice(0, 60), color: String(row.color || '#DED6F4'), viewerUids };
  }).filter(row => row.viewerUids.length);
  const viewerUids = [...new Set(albums.flatMap(row => row.viewerUids))].slice(0, 30);
  const memberUids = [user.uid, ...viewerUids];
  const albumIds = new Set(albums.map(row => row.id));
  const albumMap = new Map(albums.map(row => [row.id, row]));
  const recordRows = (Array.isArray(payload.records) ? payload.records : []).filter(record => albumIds.has(String(record?.folderId))).slice(-250);
  const mediaViewerMap = new Map();
  recordRows.forEach(row => {
    const album = albumMap.get(String(row.folderId));
    (Array.isArray(row.media) ? row.media : []).slice(0, 8).forEach(item => {
      const sourceId = String(item?.fileId || item?.key || '');
      if (!sourceId) return;
      const recipients = mediaViewerMap.get(sourceId) || new Set();
      (album?.viewerUids || []).forEach(uid => recipients.add(uid));
      mediaViewerMap.set(sourceId, recipients);
    });
  });
  const records = [];
  for (const row of recordRows) {
    const media = [];
    for (const item of (Array.isArray(row.media) ? row.media : []).slice(0, 8)) {
      const sourceId = String(item?.fileId || item?.key || '');
      if (!sourceId) continue;
      try {
        // A favorite can appear in more than one shared folder. Give the copied
        // blob the union of those folders' viewers while each record remains
        // filtered to its own selected folder.
        const sharedId = await copyMediaToSharedAlbum(sourceId, [user.uid, ...(mediaViewerMap.get(sourceId) || [])]);
        if (sharedId) media.push({ kind: item.kind === 'video' ? 'video' : 'image', sharedId, name: String(item.name || '').slice(0, 180), type: String(item.type || '') });
      } catch (error) {
        console.warn('Shared album media copy skipped', sourceId, error);
      }
    }
    records.push({ id: String(row.id), folderId: String(row.folderId), title: String(row.title || '기록').slice(0, 100), date: String(row.date || ''), body: String(row.body || '').slice(0, 600), media });
  }
  const liveSharedMediaIds = new Set(records.flatMap(record => record.media || []).map(item => item.sharedId).filter(Boolean));
  await setDoc(doc(db, 'sharedAlbums', user.uid), {
    ownerUid: user.uid,
    ownerEmail: user.email,
    ownerName: user.name,
    viewerUids,
    memberUids,
    albums,
    records,
    updatedAt: serverTimestamp(),
  });
  await pruneSharedAlbumMedia(user.uid, liveSharedMediaIds);
  return { albumCount: albums.length, recordCount: records.length, friendCount: viewerUids.length };
}

function watchSharedAlbums(callback) {
  const user = requireUser();
  return onSnapshot(
    query(collection(db, 'sharedAlbums'), where('viewerUids', 'array-contains', user.uid)),
    snapshot => callback(snapshot.docs.map(item => {
      const data = item.data();
      const albums = (Array.isArray(data.albums) ? data.albums : []).filter(album => !Array.isArray(album.viewerUids) || album.viewerUids.includes(user.uid));
      const folderIds = new Set(albums.map(album => String(album.id)));
      const records = (Array.isArray(data.records) ? data.records : []).filter(record => folderIds.has(String(record.folderId)));
      return { ...data, albums, records, id: item.id, updatedAt: timestampValue(data.updatedAt) };
    }).filter(item => item.albums.length)),
    error => console.warn('Shared album listener stopped', error),
  );
}

async function readSharedAlbumMedia(mediaId) {
  const user = requireUser();
  const ref = doc(db, 'sharedAlbumMedia', String(mediaId));
  const metaSnapshot = await getDoc(ref);
  if (!metaSnapshot.exists() || !metaSnapshot.data().memberUids?.includes(user.uid)) throw new Error('공유 앨범 미디어를 볼 권한이 없습니다.');
  const chunks = await getDocs(collection(ref, 'chunks'));
  const parts = chunks.docs.sort((a, b) => a.id.localeCompare(b.id)).map(item => item.data().data.toUint8Array());
  return new Blob(parts, { type: metaSnapshot.data().type || 'application/octet-stream' });
}

const EPHEMERAL_MEDIA_TTL_MS = 24 * 60 * 60 * 1000;

function ephemeralMediaRef(mediaId) {
  return doc(db, 'ephemeralMedia', mediaId);
}

function connectedRecipientUids() {
  const rows = [];
  if (state.partner?.uid) rows.push(state.partner.uid);
  state.friends.forEach(friend => { if (friend?.uid) rows.push(friend.uid); });
  return new Set(rows);
}

async function uploadEphemeralMedia(originalFile, recipientUids = []) {
  const user = requireUser();
  const allowed = connectedRecipientUids();
  const recipients = [...new Set((recipientUids || []).map(String))].filter(uid => allowed.has(uid));
  if (!recipients.length) throw new Error('공유할 커플 또는 친구를 선택해주세요.');
  const file = await compressImage(originalFile);
  const isVideo = String(file.type || '').startsWith('video/');
  if (!(isVideo || String(file.type || '').startsWith('image/'))) throw new Error('사진 또는 동영상만 올릴 수 있습니다.');
  if (isVideo) {
    const duration = await videoDurationSeconds(file);
    if (duration > 310) throw new Error('영상은 5분 이내로 선택해주세요.');
    if (file.size > 120 * 1024 * 1024) throw new Error('영상은 120MB 이하로 선택해주세요.');
  } else if (file.size > 25 * 1024 * 1024) {
    throw new Error('사진은 25MB 이하로 선택해주세요.');
  }
  const mediaId = `em-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const ref = ephemeralMediaRef(mediaId);
  const bytes = new Uint8Array(await file.arrayBuffer());
  const chunkSize = 700 * 1024;
  const chunkCount = Math.ceil(bytes.length / chunkSize);
  const expiresAt = Timestamp.fromMillis(Date.now() + EPHEMERAL_MEDIA_TTL_MS);
  await setDoc(ref, {
    name: file.name,
    type: file.type || 'application/octet-stream',
    size: file.size,
    chunkCount,
    createdByUid: user.uid,
    createdByEmail: user.email,
    createdByName: user.name,
    recipientUids: recipients,
    memberUids: [user.uid, ...recipients],
    createdAt: serverTimestamp(),
    expiresAt,
    ready: false,
  });
  try {
    const chunks = collection(ref, 'chunks');
    let batch = writeBatch(db);
    let operations = 0;
    for (let index = 0; index < chunkCount; index += 1) {
      const start = index * chunkSize;
      const end = Math.min(bytes.length, start + chunkSize);
      batch.set(doc(chunks, String(index).padStart(5, '0')), { data: Bytes.fromUint8Array(bytes.slice(start, end)) });
      operations += 1;
      if (operations === 400) {
        await batch.commit();
        batch = writeBatch(db);
        operations = 0;
      }
    }
    if (operations) await batch.commit();
    await updateDoc(ref, { ready: true });
  } catch (error) {
    await deleteEphemeralMedia(mediaId).catch(() => {});
    throw error;
  }
  return { id: mediaId, name: file.name, mimeType: file.type, size: file.size, expiresAt: expiresAt.toMillis() };
}

async function readEphemeralMedia(mediaId) {
  requireUser();
  const ref = ephemeralMediaRef(mediaId);
  const metaSnapshot = await getDoc(ref);
  if (!metaSnapshot.exists()) throw new Error('공유 미디어를 찾을 수 없습니다.');
  const meta = metaSnapshot.data();
  if (!meta.memberUids?.includes(state.user.uid)) throw new Error('이 미디어를 볼 권한이 없습니다.');
  if (timestampValue(meta.expiresAt) <= Date.now()) throw new Error('24시간이 지나 사라진 미디어입니다.');
  const chunkSnapshot = await getDocs(collection(ref, 'chunks'));
  const parts = chunkSnapshot.docs.sort((a, b) => a.id.localeCompare(b.id)).map(item => item.data().data.toUint8Array());
  return new Blob(parts, { type: meta.type || 'application/octet-stream' });
}

async function deleteEphemeralMedia(mediaId) {
  if (!mediaId) return;
  const user = requireUser();
  const ref = ephemeralMediaRef(mediaId);
  const snapshot = await getDoc(ref);
  if (!snapshot.exists()) return;
  if (snapshot.data().createdByUid !== user.uid) throw new Error('올린 사람만 모두에게서 삭제할 수 있습니다.');
  const chunks = await getDocs(query(collection(ref, 'chunks'), limit(500)));
  const batch = writeBatch(db);
  chunks.docs.forEach(item => batch.delete(item.ref));
  batch.delete(ref);
  await batch.commit();
}

function watchEphemeralMedia(callback) {
  const user = requireUser();
  return onSnapshot(
    query(collection(db, 'ephemeralMedia'), where('memberUids', 'array-contains', user.uid)),
    snapshot => {
      const now = Date.now();
      const expiredOwned = [];
      const rows = snapshot.docs.map(item => {
        const row = plainDoc(item) || {};
        return { ...row, createdAt: timestampValue(row.createdAt), expiresAt: timestampValue(row.expiresAt) };
      }).filter(row => {
        const expired = row.expiresAt > 0 && row.expiresAt <= now;
        if (expired && row.createdByUid === user.uid) expiredOwned.push(row.id);
        return row.ready && !expired;
      }).sort((a, b) => b.createdAt - a.createdAt);
      callback(rows);
      expiredOwned.forEach(id => deleteEphemeralMedia(id).catch(() => {}));
    },
    error => console.warn('24-hour media listener stopped', error),
  );
}

function privateMediaRef(mediaId) {
  const user = requireUser();
  return doc(db, 'users', user.uid, 'privateMedia', mediaId);
}

async function uploadPrivateMedia(originalFile, label = 'personal') {
  const context = captureMediaUploadContextV176(true);
  const file = await compressImage(originalFile);
  context.assertCurrent();
  const maxSize = 25 * 1024 * 1024;
  if (file.size > maxSize) throw new Error('무료 저장공간 보호를 위해 파일은 25MB 이하만 올릴 수 있습니다.');
  const mediaId = `pm-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const ref = doc(db, ...context.base, mediaId);
  const bytes = new Uint8Array(await file.arrayBuffer());
  context.assertCurrent();
  const chunkSize = 700 * 1024;
  const chunkCount = Math.ceil(bytes.length / chunkSize);
  await writeMediaChunksV178(context, ref, bytes, {
    name: file.name,
    type: file.type || 'application/octet-stream',
    size: file.size,
    chunkCount,
    label,
    createdAt: serverTimestamp(),
    createdBy: context.uid,
  });
  context.assertCurrent();
  return { id: mediaId, name: file.name, mimeType: file.type, size: file.size };
}

async function readPrivateMedia(mediaId) {
  const ref = privateMediaRef(mediaId);
  const metaSnapshot = await getDoc(ref);
  if (!metaSnapshot.exists()) throw new Error('개인 사진을 찾을 수 없습니다.');
  const meta = metaSnapshot.data();
  const chunkSnapshot = await getDocs(collection(ref, 'chunks'));
  const parts = chunkSnapshot.docs.sort((a, b) => a.id.localeCompare(b.id)).map(item => item.data().data.toUint8Array());
  return new Blob(parts, { type: meta.type || 'application/octet-stream' });
}

async function deletePrivateMedia(mediaId) {
  if (!mediaId) return;
  const ref = privateMediaRef(mediaId);
  const chunkSnapshot = await getDocs(query(collection(ref, 'chunks'), limit(500)));
  const batch = writeBatch(db);
  chunkSnapshot.docs.forEach(item => batch.delete(item.ref));
  batch.delete(ref);
  await batch.commit();
}

function paperTaskMediaRef(mediaId) {
  requirePaperTaskMember();
  return doc(db, 'sharedWorkspaces', PAPER_TASK_WORKSPACE_ID, 'media', mediaId);
}

async function uploadPaperTaskMedia(originalFile, label = 'consulting-client-file') {
  const user = requirePaperTaskMember();
  const file = await compressImage(originalFile);
  const maxSize = 25 * 1024 * 1024;
  if (file.size > maxSize) throw new Error('공동 작업공간 파일은 25MB 이하만 올릴 수 있습니다.');
  const mediaId = `ptm-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const ref = paperTaskMediaRef(mediaId);
  const bytes = new Uint8Array(await file.arrayBuffer());
  const chunkSize = 700 * 1024;
  const chunkCount = Math.ceil(bytes.length / chunkSize);
  const chunks = collection(ref, 'chunks');
  let batch = writeBatch(db);
  let operations = 0;
  for (let index = 0; index < chunkCount; index += 1) {
    const start = index * chunkSize;
    const end = Math.min(bytes.length, start + chunkSize);
    batch.set(doc(chunks, String(index).padStart(5, '0')), { data: Bytes.fromUint8Array(bytes.slice(start, end)) });
    operations += 1;
    if (operations === 400) {
      await batch.commit();
      batch = writeBatch(db);
      operations = 0;
    }
  }
  if (operations) await batch.commit();
  await setDoc(ref, {
    name: file.name,
    type: file.type || 'application/octet-stream',
    size: file.size,
    chunkCount,
    label,
    createdAt: serverTimestamp(),
    createdBy: user.uid,
    createdByEmail: user.email,
  });
  return { id: mediaId, name: file.name, mimeType: file.type, size: file.size };
}

async function readPaperTaskMedia(mediaId) {
  const ref = paperTaskMediaRef(mediaId);
  const metaSnapshot = await getDoc(ref);
  if (!metaSnapshot.exists()) throw new Error('공동 작업공간 파일을 찾을 수 없습니다.');
  const meta = metaSnapshot.data();
  const chunkSnapshot = await getDocs(collection(ref, 'chunks'));
  const parts = chunkSnapshot.docs.sort((a, b) => a.id.localeCompare(b.id)).map(item => item.data().data.toUint8Array());
  return new Blob(parts, { type: meta.type || 'application/octet-stream' });
}

async function deletePaperTaskMedia(mediaId) {
  if (!mediaId) return;
  const ref = paperTaskMediaRef(mediaId);
  const chunkSnapshot = await getDocs(query(collection(ref, 'chunks'), limit(500)));
  const batch = writeBatch(db);
  chunkSnapshot.docs.forEach(item => batch.delete(item.ref));
  batch.delete(ref);
  await batch.commit();
}

const CLIENT_INTAKE_TOKEN = /^[A-Za-z0-9_-]{32,100}$/;
const intakeText = (value, max) => String(value || '').trim().slice(0, max);
const intakeList = (value, max = 20) => (Array.isArray(value) ? value : String(value || '').split(/[;,\n]/))
  .map((item) => intakeText(item, 120))
  .filter(Boolean)
  .slice(0, max);

function randomClientIntakeToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function clientIntakeRef(token) {
  if (!CLIENT_INTAKE_TOKEN.test(String(token || ''))) throw new Error('고객 작성 링크 형식이 올바르지 않습니다.');
  return doc(db, 'clientIntakeLinks', String(token));
}

async function createClientIntakeLink(preferredToken = '', previousToken = '') {
  const user = requireUser();
  let token = CLIENT_INTAKE_TOKEN.test(String(preferredToken || '')) ? String(preferredToken) : '';
  const activePayload = {
    ownerUid: user.uid,
    ownerName: intakeText(user.name, 80),
    active: true,
    updatedAt: serverTimestamp(),
  };
  if (token) {
    try {
      await setDoc(clientIntakeRef(token), activePayload, { merge: true });
      return token;
    } catch {
      try {
        await setDoc(clientIntakeRef(token), { ...activePayload, createdAt: serverTimestamp() });
        return token;
      } catch {
        token = '';
      }
    }
  }
  if (previousToken && previousToken !== token && CLIENT_INTAKE_TOKEN.test(String(previousToken))) {
    await updateDoc(clientIntakeRef(previousToken), { active: false, updatedAt: serverTimestamp() }).catch(() => {});
  }
  token = randomClientIntakeToken();
  await setDoc(clientIntakeRef(token), { ...activePayload, createdAt: serverTimestamp() });
  return token;
}

async function getClientIntakeLink(token) {
  const snapshot = await getDoc(clientIntakeRef(token));
  if (!snapshot.exists()) throw new Error('존재하지 않는 고객 작성 링크입니다.');
  const row = snapshot.data();
  return { active: row.active === true, ownerName: intakeText(row.ownerName, 80) };
}

async function submitClientIntake(token, payload = {}) {
  const applicationYear = Math.max(2000, Math.min(2200, Number(payload.applicationYear) || 0));
  const applicationSemester = ['spring', 'fall', 'rolling', 'other'].includes(payload.applicationSemester)
    ? payload.applicationSemester
    : '';
  const data = {
    name: intakeText(payload.name, 60),
    phone: intakeText(payload.phone, 30),
    email: intakeText(payload.email, 120),
    birthYear: Math.max(0, Math.min(2200, Number(payload.birthYear) || 0)),
    gender: ['female', 'male'].includes(payload.gender) ? payload.gender : '',
    currentSchool: intakeText(payload.currentSchool, 120),
    currentMajor: intakeText(payload.currentMajor, 120),
    targetUniversity: intakeText(payload.targetUniversity, 120),
    targetMajor: intakeText(payload.targetMajor, 120),
    advisorNames: intakeList(payload.advisorNames, 20),
    degree: ['masters', 'doctoral', 'integrated', 'other'].includes(payload.degree) ? payload.degree : '',
    gpa: Math.max(0, Math.min(100, Number(payload.gpa) || 0)),
    gpaScale: [4, 4.3, 4.5, 100].includes(Number(payload.gpaScale)) ? Number(payload.gpaScale) : 0,
    applicationYear,
    applicationSemester,
    topic: intakeText(payload.topic, 1200),
    languageSpec: intakeText(payload.languageSpec, 1200),
    certifications: intakeText(payload.certifications, 1200),
    activities: intakeText(payload.activities, 1600),
    researchExperience: intakeText(payload.researchExperience, 1600),
    outputs: intakeText(payload.outputs, 1600),
    inquiry: intakeText(payload.inquiry, 2000),
    note: intakeText(payload.note, 6000),
    consent: true,
    source: 'external-intake-v4',
    status: 'new',
    createdAt: serverTimestamp(),
  };
  if (!data.name || !data.phone || !data.email || !data.birthYear || !data.gender || !applicationYear || !applicationSemester) {
    throw new Error('개인 정보와 진학 희망 학년도·학기를 모두 입력해주세요.');
  }
  if ((data.gpa && !data.gpaScale) || (!data.gpa && data.gpaScale)) {
    throw new Error('학점과 학점 만점을 함께 입력해주세요.');
  }
  const link = await getDoc(clientIntakeRef(token));
  if (!link.exists() || link.data().active !== true) throw new Error('만료되었거나 교체된 작성 링크입니다.');
  const ref = await addDoc(collection(clientIntakeRef(token), 'submissions'), data);
  return ref.id;
}

function watchClientIntakeSubmissions(token, callback) {
  const user = requireUser();
  const ref = clientIntakeRef(token);
  return onSnapshot(
    query(collection(ref, 'submissions'), where('status', '==', 'new'), limit(100)),
    snapshot => callback(snapshot.docs.map(item => ({
      id: item.id,
      ...item.data(),
      createdAt: timestampValue(item.data().createdAt),
    }))),
    error => console.warn('Client intake listener stopped', error),
  );
}

async function markClientIntakeImported(token, submissionId) {
  requireUser();
  if (!/^[A-Za-z0-9_-]{8,100}$/.test(String(submissionId || ''))) return;
  await updateDoc(doc(clientIntakeRef(token), 'submissions', String(submissionId)),{status:'imported',importedAt:serverTimestamp()});
}

const LAB_NOTEBOOK_TOKEN = /^[A-Za-z0-9_-]{32,100}$/;
function labNotebookRef(token) {
  if (!LAB_NOTEBOOK_TOKEN.test(String(token || ''))) throw new Error('실험노트 링크 형식이 올바르지 않습니다.');
  return doc(db, 'labNotebookLinks', String(token));
}
function randomLabNotebookToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
async function createLabNotebookLinks(existing = []) {
  const user = requirePaperTaskMember();
  const source = Array.isArray(existing) ? existing : [];
  const rows = [];
  for (let index = 0; index < 5; index += 1) {
    const old = source[index] || {};
    const token = LAB_NOTEBOOK_TOKEN.test(String(old.token || '')) ? String(old.token) : randomLabNotebookToken();
    const ref = labNotebookRef(token);
    let snapshot = null;
    try { snapshot = await getDoc(ref); }
    catch (error) {
      console.info('[lab-notebook] creating a new fixed researcher link', index + 1);
    }
    const payload = {
      ownerUid: user.uid,
      ownerEmail: intakeText(user.email, 120).toLowerCase(),
      researcherName: intakeText(old.researcherName || `연구원 ${index + 1}`, 60),
      label: intakeText(old.label || `LAB NOTE ${String(index + 1).padStart(2, '0')}`, 80),
      slot: index + 1,
      active: true,
      updatedAt: serverTimestamp(),
    };
    if (snapshot?.exists()) await setDoc(ref, payload, { merge: true });
    else await setDoc(ref, { ...payload, createdAt: serverTimestamp() });
    rows.push({ token, researcherName: payload.researcherName, label: payload.label, slot: payload.slot });
  }
  return rows;
}
async function getLabNotebookLink(token) {
  const snapshot = await getDoc(labNotebookRef(token));
  if (!snapshot.exists() || snapshot.data().active !== true) throw new Error('존재하지 않거나 비활성화된 실험노트 링크입니다.');
  const row = snapshot.data();
  return { active:true, researcherName:intakeText(row.researcherName,60), label:intakeText(row.label,80) };
}
async function submitLabNotebook(token, payload = {}, originalFiles = []) {
  const link = await getDoc(labNotebookRef(token));
  if (!link.exists() || link.data().active !== true) throw new Error('만료되었거나 비활성화된 실험노트 링크입니다.');
  const files = Array.from(originalFiles || []).slice(0, 3);
  for (const file of files) {
    if (!/^(image|video)\//.test(file.type || '')) throw new Error('사진 또는 영상 파일만 첨부할 수 있습니다.');
    if (file.size > 25 * 1024 * 1024) throw new Error('첨부 파일은 각각 25MB 이하여야 합니다.');
  }
  const ref = doc(collection(labNotebookRef(token), 'submissions'));
  const media = files.map((file, index) => ({ id:`labm-${Date.now()}-${index}-${crypto.randomUUID().slice(0,8)}`, name:intakeText(file.name,160), type:intakeText(file.type,100), size:file.size }));
  const data = {
    researcher:intakeText(payload.researcher,60), performedAt:intakeText(payload.performedAt,30),
    title:intakeText(payload.title,160), project:intakeText(payload.project,120), code:intakeText(payload.code,80),
    protocol:intakeText(payload.protocol,80), batch:intakeText(payload.batch,100), purpose:intakeText(payload.purpose,2000),
    materials:intakeText(payload.materials,3000), procedure:intakeText(payload.procedure,5000),
    qcCriteria:intakeText(payload.qcCriteria,400), qcResult:['확인 전','통과','조건부 통과','재실험 필요'].includes(payload.qcResult)?payload.qcResult:'확인 전',
    result:intakeText(payload.result,5000), nextAction:intakeText(payload.nextAction,1200), media,
    source:'external-lab-notebook-v158', status:'new', createdAt:serverTimestamp(),
  };
  if (!data.researcher || !data.performedAt || !data.title || !data.procedure || !data.result) throw new Error('연구원, 일시, 제목, 절차와 결과를 입력해주세요.');
  await setDoc(ref, data);
  for (let fileIndex = 0; fileIndex < files.length; fileIndex += 1) {
    const file = files[fileIndex], descriptor = media[fileIndex], mediaRef = doc(ref, 'media', descriptor.id);
    await setDoc(mediaRef, { ...descriptor, createdAt:serverTimestamp() });
    const bytes = new Uint8Array(await file.arrayBuffer()), chunkSize = 700 * 1024, chunks = collection(mediaRef, 'chunks');
    let batch = writeBatch(db), operations = 0;
    for (let offset = 0, index = 0; offset < bytes.length; offset += chunkSize, index += 1) {
      batch.set(doc(chunks, String(index).padStart(5, '0')), { data:Bytes.fromUint8Array(bytes.slice(offset, Math.min(bytes.length, offset + chunkSize))) });
      operations += 1;
      if (operations === 400) { await batch.commit(); batch = writeBatch(db); operations = 0; }
    }
    if (operations) await batch.commit();
  }
  return ref.id;
}
async function readLabNotebookSubmissions(links = []) {
  requirePaperTaskMember();
  const rows = [];
  for (const link of (Array.isArray(links) ? links : []).slice(0, 5)) {
    if (!LAB_NOTEBOOK_TOKEN.test(String(link?.token || ''))) continue;
    const snapshot = await getDocs(query(collection(labNotebookRef(link.token), 'submissions'), limit(200)));
    snapshot.docs.forEach(item => rows.push({ id:item.id, token:link.token, slot:link.slot, linkLabel:link.label, ...item.data(), createdAt:timestampValue(item.data().createdAt) }));
  }
  return rows.sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));
}
async function readLabNotebookMedia(token, submissionId, mediaId) {
  requirePaperTaskMember();
  const ref = doc(labNotebookRef(token), 'submissions', String(submissionId), 'media', String(mediaId));
  const metaSnapshot = await getDoc(ref);
  if (!metaSnapshot.exists()) throw new Error('실험노트 첨부 파일을 찾을 수 없습니다.');
  const meta = metaSnapshot.data(), chunkSnapshot = await getDocs(collection(ref, 'chunks'));
  const parts = chunkSnapshot.docs.sort((a,b)=>a.id.localeCompare(b.id)).map(item=>item.data().data.toUint8Array());
  return new Blob(parts,{type:meta.type||'application/octet-stream'});
}

// Archives are made only while signed in and in the foreground. A failed or
// interrupted run resumes from server cursors; it never deletes source records.
let archiveBusyV168=false;
async function compactQuarterly(){
  const user=auth.currentUser;if(!user||archiveBusyV168||document.visibilityState==='hidden'||navigator.onLine===false)return false;
  const uid=user.uid,quarter=new Date().getFullYear()+'-Q'+(1+Math.floor(new Date().getMonth()/3)),key='aiderlog-archive168:'+uid;
  try{if(localStorage.getItem(key)===quarter)return true}catch{}
  archiveBusyV168=true;
  try{
    const token=await user.getIdToken();if(auth.currentUser?.uid!==uid)return false;
    const response=await fetch('/api/storage',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({action:'compact',storageVersion:168}),signal:AbortSignal.timeout(25000)});
    const result=await response.json();if(!response.ok)throw Error(result.error||'압축을 완료하지 못했습니다.');
    if(auth.currentUser?.uid!==uid)return false;
    if(result.done||result.alreadyComplete){try{localStorage.setItem(key,quarter)}catch{}}
    window.dispatchEvent(new CustomEvent('aiderlog-storage-v168',{detail:{...result,uid}}));
    if(!result.done&&!result.alreadyComplete)setTimeout(()=>{if(auth.currentUser?.uid===uid)compactQuarterly().catch(error=>console.warn('Archive deferred',error))},15000);
    return result;
  }finally{archiveBusyV168=false}
}

const friendScheduleAdapterV175 = createFriendScheduleAdapter({db,getContext:()=>{
  const user=requireUser();
  if(auth.currentUser?.uid!==user.uid)throw Object.assign(new Error('로그인 계정이 변경되었습니다.'),{code:'unauthenticated'});
  return {user,friends:state.friends};
}});

const api = {
  compactQuarterly,
  config: { projectId: firebaseConfig.projectId, authDomain: firebaseConfig.authDomain },
  getState: () => ({ ...state, user:publicStateUserV175() }),
  subscribe(callback) {
    subscribers.add(callback);
    callback({ ...state, user:publicStateUserV175() });
    return () => subscribers.delete(callback);
  },
  login,
  completeAndroidGoogleSignIn: androidSessionV176.complete,
  logout,
  createInvite,
  acceptInvite,
  repairPairConnection,
  rejectInvite,
  cancelInvite,
  disconnectPair,
  createFriendInvite,
  acceptFriendInvite,
  rejectFriendInvite,
  cancelFriendInvite,
  removeFriend,
  sendDirectLetter,
  markDirectLetterRead,
  readAppData,
  readDdayData,
  mutateDday,
  readPrivateCalendarData,
  mutatePrivateCalendar,
  watchPrivateCalendarPair,
  migrateEventWorkspace,
  writeAppData,
  readScheduleData,
  writeScheduleData,
  watchScheduleData,
  readFriendSchedule: friendScheduleAdapterV175.read,
  friendScheduleTargets: friendScheduleAdapterV175.targets,
  setFriendScheduleTargets: friendScheduleAdapterV175.setTargets,
  removeFriendSchedule: friendScheduleAdapterV175.remove,
  getFirebaseIdToken,
  readPrivateData,
  writePrivateData,
  applyWidgetActionV165,
  readPaperTaskData,
  writePaperTaskData,
  watchPaperTaskData,
  readPaperAnalysis,
  writePaperAnalysis,
  deletePaperAnalysis,
  readEmotionData,
  writeEmotionData,
  uploadMedia,
  readMedia,
  deleteMedia,
  publishSharedAlbums,
  watchSharedAlbums,
  readSharedAlbumMedia,
  uploadEphemeralMedia,
  readEphemeralMedia,
  deleteEphemeralMedia,
  watchEphemeralMedia,
  uploadPrivateMedia,
  readPrivateMedia,
  deletePrivateMedia,
  uploadPaperTaskMedia,
  readPaperTaskMedia,
  deletePaperTaskMedia,
  requestGoogleDriveAccess,
  requestGoogleCalendarAccess,
  listGoogleCalendars,
  listGoogleCalendarEvents,
  backupEventDataToGoogleDrive,
  backupPaperTaskDataToGoogleDrive,
  updateNickname,
  updateProfileSettings,
  createClientIntakeLink,
  getClientIntakeLink,
  submitClientIntake,
  watchClientIntakeSubmissions,
  markClientIntakeImported,
  createLabNotebookLinks,
  getLabNotebookLink,
  submitLabNotebook,
  readLabNotebookSubmissions,
  readLabNotebookMedia,
};

window.AiderDearFirebase = api;
window.dispatchEvent(new CustomEvent('aiderdear-firebase-ready'));

await prepareLoginPersistenceV176().catch(error=>{state.error=error.message;console.warn('[AiderLog authentication] persistence',error.code);});
let authObserverGenerationV176=0;
onAuthStateChanged(auth, async user => {
  const generation=++authObserverGenerationV176;
  const stillCurrent=()=>generation===authObserverGenerationV176&&(auth.currentUser?.uid||null)===(user?.uid||null);
  stopListeners();
  state.user = null;
  state.pair = null;
  state.partner = null;
  state.incoming = [];
  state.outgoing = [];
  state.friends = [];
  state.friendIncoming = [];
  state.friendOutgoing = [];
  state.directLetters = [];
  state.error = '';
  state.ready=false;
  emit();
  if (user) {
    try {
      // Employee accounts never enter the general site's profile/listener boot.
      // This self-only lookup contains no employee private records.
      const workIdentity=await getDoc(doc(db,'workIdentities',user.uid));
      if(!stillCurrent())return;
      if(workIdentity.data()?.kind==='employee'){
        state.ready=true;state.error='직원 개인 페이지로 이동합니다.';emit();
        location.replace(new URL('./employee.html',location.href).href);return;
      }
      const profile=await ensureUserProfile(user);
      if(!stillCurrent())return;
      state.user = profile;
      startListeners(user);
      propagateMemberProfile(state.user).catch(error => console.warn('Connected profile sync skipped', error));
      setTimeout(() => repairPairConnection().catch(error => {
        console.warn('Pair connection repair skipped', error);
      }), 700);
    } catch (error) {
      if(!stillCurrent())return;
      state.error = error.message;
    }
  }
  if(!stillCurrent())return;
  state.ready = true;
  emit();
});
